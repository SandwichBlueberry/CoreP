<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     *
     * @return void
     */
    public function register()
    {
//        $this->reportable(function (Throwable $e) {
//            //
//        });
        $this->renderable(function(\Exception $e, $request) {
            return $this->handleException($request, $e);
        });
    }
    public function handleException($request, \Exception $exception)
    {
        try {
            \DB::connection()->getPdo();
            if(\DB::connection()->getDatabaseName()){

            }else {
                $msg ='Sorry DB Not Found';
                return response()->view('handler.db-handler',compact('msg'));
            }
        } catch (\Exception $e) {
            $msg ='Sorry, '.$e->getMessage();
            return response()->view('handler.db-handler',compact('msg'));
        }
//        if($exception instanceof Throwable) {
//            return response($exception->getMessage() .' Line '. $exception->getLine(), 404);
//        }
    }
}
