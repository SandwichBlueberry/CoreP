<?php
/**
 * Created by PhpStorm.
 * User: Giw
 * Date: 12/12/2017
 * Time: 10:31 AM
 */
namespace App\Transaksi;

use App\Master\SettingDataFixed;
class DiagnosaTindakanPasien extends Transaksi
{
    protected $table ="diagnosapasienicdixtr";
//    protected $fillable = ['tglpendaftaran'];
    public $timestamps = false;
    public $incrementing = false;
    protected $primaryKey = "norec";
}
