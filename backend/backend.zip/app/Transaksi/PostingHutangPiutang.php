<?php

namespace App\Transaksi;

class PostingHutangPiutang extends Transaksi
{
    protected $table = 'postinghutangpiutangtr';
    protected $fillable = [];
    public $timestamps = false;
    public $incrementing = false;
    protected $primaryKey = "norec";


}
