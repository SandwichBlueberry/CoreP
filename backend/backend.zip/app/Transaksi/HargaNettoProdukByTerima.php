<?php
namespace App\Transaksi;

class HargaNettoProdukByTerima extends Transaksi
{
    protected $table ="harganettoprodukbyterima_t";
    protected $fillable = [];
    public $timestamps = false;
    public $incrementing = false;

}
