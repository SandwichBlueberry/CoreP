<?php
namespace App\Transaksi;

use App\Master\SettingDataFixed;
class BatalRegistrasi extends Transaksi
{
    protected $table ="batalregistrasitr";
    protected $fillable = ['alasanpembatalan'];
    public $timestamps = false;
    public $incrementing = false;
    protected $primaryKey = "norec";
    protected $depositId= null;

    public  function pasiendaftar(){
        return $this->belongsTo('App\Transaksi\PasienDaftar', 'registrasipasienfk');
    }

    public function pembatalan(){
        return $this->belongsTo('App\Master\Pembatalan', 'pembatalanidfk');
    }

    public function pegawai(){
        return $this->belongsTo('App\Master\Pegawai', 'pegawaiidfk');
    }

}
