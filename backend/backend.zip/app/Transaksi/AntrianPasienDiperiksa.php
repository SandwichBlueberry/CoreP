<?php
namespace App\Transaksi;

class AntrianPasienDiperiksa extends Transaksi
{
    protected $table ="daftarpasienruangantr";
    protected $fillable = [];
    public $timestamps = false;
    public $incrementing = false;
    protected $primaryKey = "norec";

//    public function __construct(){$this->setTransformerPath('App\Transformers\Transaksi\PeriodeAccountTransformer');}

    public function pelayanan_pasien(){
        return $this->belongsTo('App\Transaksi\PelayananPasien',  'daftarpasienruanganfk','norec');
    }

    public  function ruangan(){
        return $this->belongsTo('App\Master\Ruangan', 'ruanganidfk', 'id');
    }
//
//    public function kelas(){
//        return $this->belongsTo('App\Master\Kelas', 'objectkelasfk');
//    }
//
//    public function kelompok_pasien(){
//        return $this->belongsTo('App\Master\KelompokPasien', 'objectkelompokpasienlastfk');
//    }
    public function pasien_daftar(){
        return $this->belongsTo('App\Transaksi\PasienDaftar', 'registrasipasienfk');
    }
    public function kamar(){
        return $this->belongsTo('App\Transaksi\Kamar', 'kamaridfk');
    }
}
