<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 31/5/2021
 * Time: 8:40 AM
 */


namespace App\Http\Controllers\EIS;

use App\Http\Controllers\ApiController;
use App\Master\Departemen;
use App\Master\JenisIndikator;
use App\Master\KelompokTransaksi;
use App\Master\Pasien;
use App\Master\SettingDataFixed;
use App\Master\TargetIndikator;
use App\Transaksi\IndikatorPasienJatuh;
use App\Transaksi\IndikatorRensar;
use App\Transaksi\IndikatorRensarDetail;
use App\Transaksi\PasienDaftar;
use App\Transaksi\PelayananPasien;
use Carbon\Carbon;
use Illuminate\Http\Request;
use DB;
use App\Transaksi\BPJSKlaimTxt;
use App\Traits\Valet;
use Jimmyjs\ReportGenerator\ReportMedia\PdfReport;

class EISC extends ApiController
{
    use Valet;

    public function __construct()
    {
        parent::__construct($skip_authentication = false);
    }

    public function getDashboard(Request $r)
    {
        $kdProfile = $this->getDataKdProfile($r);
        $result['trendkunjungan'] = $this->trendKunjungan($kdProfile);
        return $this->respond($result);
    }

    function trendKunjungan($kdProfile)
    {
        $minggu = Carbon::now()->subDay(14)->format('Y-m-d');
        $tanggal = Carbon::now()->addDay(1)->format('Y-m-d');

        $begin = new \DateTime($minggu);
        $end = new \DateTime($tanggal);
        $interval = \DateInterval::createFromDateString('1 day');
        $period = new \DatePeriod($begin, $interval, $end);

        $set = explode(',', $this->settingDataFixed('kdDeptEis', $kdProfile));
        $kdDept = [];
        foreach ($set as $s) {
            $kdDept [] = (int)$s;
        }
        $deptDa = Departemen::whereIN('id',$kdDept)->where('aktif',true)->get();
//        dd($deptDa);
        $array = [];
        foreach ($period as $dt) {
            $array[] = array(
                'tgl' => $dt->format("Y-m-d"),
                'jml' => 0,
                'tglstring' => $dt->format("d F Y"),
            );
        }
        $data = DB::table('registrasipasientr as rp')
            ->join('ruanganmt as ru','ru.id','=','rp.ruanganlastidfk')
            ->join('instalasimt as ins','ins.id','=','ru.instalasiidfk')
            ->select(DB::raw("to_char(rp.tglregistrasi,'yyyy-mm-dd') as tgl,ins.namadepartemen"))
            ->whereBetween('rp.tglregistrasi', [$minggu, $tanggal])
            ->where('rp.aktif',true)
//            ->groupby('ins.namadepartemen')
            ->get();
//        dd($data);
        $data2 = [];
        $sama = false;
        foreach ($array as $value) {
            $sama = false;
            foreach ($data as $value2) {
                if ($value['tgl'] == $value2->tgl ) {
                    $data2[] = [
                        'tgl' => $value['tgl'],
                        'tglstring' => $value['tglstring'],
                        'jml' =>(float) $value['jml'] +1 ,

                    ];
                    $sama = true;

                }
            }
            if ($sama == false) {
                $data2[] = [
                    'tgl' => $value['tgl'],
                    'tglstring' => $value['tglstring'],
                    'jml' => $value['jml'],
                ];
            }

        }
//        {
//            label: 'Tingkat 1',
//            backgroundColor: '#FF6384',
//            borderColor: '#1E88E5',
//            data: seriesTKT1
//          }

        return $data2;
    }

}
