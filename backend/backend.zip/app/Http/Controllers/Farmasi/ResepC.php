<?php
/**
 * FarmasiController
 * Created by PhpStorm.
 * User: as@epic
 * Date: 08/08/2017
 * Time: 12:48
 */

/**
 * Created by PhpStorm.
 * User: nengepic
 * Date: 09/08/2019
 * Time: 10:27
 */

namespace App\Http\Controllers\Farmasi;

use App\Http\Controllers\ApiController;
use App\Master\DiklatKategory;
use App\Master\SatuanResep;
use App\Transaksi\LoggingUser;
use App\Transaksi\OrderPelayanan;
use App\Transaksi\PasienDaftar;
use App\Transaksi\PelayananPasienObatKronis;
use App\Transaksi\StrukOrderBatalVerif;
use App\Transaksi\StrukOrderBatalVerifDetail;
use Illuminate\Http\Request;
use App\Traits\Valet;
use DB;

use App\Transaksi\StrukOrder;
use App\Transaksi\StrukResep;
use App\Master\Pegawai;
use App\Master\LoginUser;
use App\Transaksi\PelayananPasien;
use App\Transaksi\PelayananPasienDetail;
use App\Transaksi\StokProdukDetail;
use App\Transaksi\KartuStok;
use App\Transaksi\PelayananPasienPetugas;
use App\Transaksi\StrukRetur;
use App\Transaksi\PelayananPasienRetur;
use App\Transaksi\AntrianApotik;


class ResepC extends ApiController
{
    use Valet;

    public function __construct()
    {
        parent::__construct($skip_authentication = false);
    }

    public function getProdukDetail(Request $request)
    {
        $kdProfile = $this->getDataKdProfile($request);
        $idProfile = (int)$kdProfile;
        //        namafield	nilaifield	keteranganfungsi
//        MetodeAmbilHargaNetto	0	KOSONG .: pengambilan hn1 atau hn2

//        MetodeHargaNetto	2	AVG
//        MetodeHargaNetto	3	Harga Tertinggi
//        MetodeHargaNetto	1	Harga Netto #

//        MetodeStokHargaNetto	2	LIFO
//        MetodeStokHargaNetto	3	FEFO #
//        MetodeStokHargaNetto	4	LEFO
//        MetodeStokHargaNetto	1	FIFO
//        MetodeStokHargaNetto	5	Summary

//        SistemHargaNetto	7	Harga Terakhir #
//        SistemHargaNetto	6	LEFO
//        SistemHargaNetto	2	LIFO
//        SistemHargaNetto	3	Harga Tertinggi
//        SistemHargaNetto	4	AVG
//        SistemHargaNetto	5	FEFO
//        SistemHargaNetto	1	FIFO

        //bucat : # setting yg dipakai
        //        select * from settingdatafixed_m where kelompok  in ('Harga Farmasi') order by namafield;
//        select * from persenhargajualproduk_m where objectjenistransaksifk =5; .:25%
        $metodeambilharganetto = $this->settingDataFixed('metodeambilharganetto', $kdProfile);

        if (empty($metodeambilharganetto)) {
            return $this->respond(array(
                'Error' => 'Setting Data Fixed Farmasi dulu',
                'message' => 'as@epic',
            ));
        }
        $strMetodeAmbilHargaNetto = $metodeambilharganetto;
//        $strMetodeHargaNetto = $jenisTransaksi->metodeharganetto; //ketika penerimaan saja
        $strMetodeStokHargaNetto = $this->settingDataFixed('metodestokharganetto', $kdProfile);
        $strSistemHargaNetto = $this->settingDataFixed('sistemharganetto', $kdProfile);

        $persenHargaJualProduk = array(
            [
                'rangemin' => (float) $this->settingDataFixed('rangeMin', $kdProfile),
                'rangemax' => (float) $this->settingDataFixed('rangeMax', $kdProfile),
                'persenuphargasatuan' =>(float)  $this->settingDataFixed('persenMin', $kdProfile)
            ],
            [
                'rangemin' =>(float) $this->settingDataFixed('rangeMax', $kdProfile),
                'rangemax' => 9999999999,
                'persenuphargasatuan' => (float) $this->settingDataFixed('persenMax', $kdProfile)
            ]
        );
//        return $persenHargaJualProduk;
//        $persenHargaJualProduk = \DB::table('persenhargajualproduk_m as phjp')
//            ->JOIN('range_m as rg', 'rg.id', '=', 'phjp.objectrangefk')
//            ->select('rg.rangemin', 'rg.rangemax', 'phjp.persenuphargasatuan')
//            ->where('phjp.objectjenistransaksifk', 5)
//            ->where('phjp.statusenabled', true)
//            ->get();
        if (count($persenHargaJualProduk) == 0) {
            return $this->respond(array(
                'Error' => 'Setting persenhargajualproduk_m dulu',
                'message' => 'as@epic',
            ));
        }

//        $persenUpHargaSatuan = $persenHargaJualProduk->persenuphargasatuan;
        $strHN = '';
        $strMSHT = '';
        $SistemHargaNetto = '';
        $MetodeAmbilHargaNetto = '';
        $MetodeStokHargaNetto = '';

        // ### FIFO ### //
        if ($strSistemHargaNetto == 1) {
            $SistemHargaNetto = 'FIFO';

            if ($strMetodeAmbilHargaNetto == 1) {//HN1
                $strHN = 'spd.harganetto1';
                $MetodeAmbilHargaNetto = 'HN1';
            }
            if ($strMetodeAmbilHargaNetto == 2) {//HN2
                $strHN = 'spd.harganetto2';
                $MetodeAmbilHargaNetto = 'HN2';
            }

            if ($strMetodeStokHargaNetto == 1) {//FIFO
                $strMSHT = 'sk.tglstruk';
                $MetodeStokHargaNetto = 'FIFO';
            }
            if ($strMetodeStokHargaNetto == 2) {//LIFO
                $strMSHT = '';
                $MetodeStokHargaNetto = 'LIFO';
            }
            if ($strMetodeStokHargaNetto == 3) {//FEFO
                $strMSHT = 'spd.tglkadaluarsa';
                $MetodeStokHargaNetto = 'FEFO';
            }
            if ($strMetodeStokHargaNetto == 4) {//LEFO
                $strMSHT = '';
                $MetodeStokHargaNetto = 'LEFO';
            }
            if ($strMetodeStokHargaNetto == 5) {//Summary
                $strMSHT = '';
                $MetodeStokHargaNetto = 'Summary';
            }
            $result = DB::select(DB::raw("select sk.norec,spd.produkidfk as objectprodukfk, $strMSHT as tgl,spd.asalprodukidfk as objectasalprodukfk,$strHN as harganetto ,
                      spd.hargadiscount,sum(spd.qtyproduk) as qtyproduk,spd.ruanganidfk as objectruanganfk,ap.asalproduk,spd.nostrukterimafk,spd.tglkadaluarsa
                from transaksistoktr as spd
                inner JOIN strukpelayanantr as sk on sk.norec=spd.nostrukterimafk
                inner JOIN asalprodukmt as ap on ap.id=spd.asalprodukidfk
                where spd.koders = $idProfile and spd.produkidfk =:produkId and spd.ruanganidfk =:ruanganid
                group by sk.norec,spd.produkidfk, $strMSHT,spd.asalprodukidfk,
                        $strHN,spd.hargadiscount,
                spd.ruanganidfk,ap.asalproduk,spd.nostrukterimafk
                order By $strMSHT"),
                array(
                    'produkId' => $request['produkfk'],
                    'ruanganid' => $request['ruanganfk'],
                )
            );

            $persenUpHargaSatuan = 0;
            foreach ($result as $item) {
                foreach ($persenHargaJualProduk as $hitem) {
                    if ((float)$hitem['rangemin'] < (float)$item->harganetto && (float)$hitem['rangemax'] > (float)$item->harganetto) {
                        $persenUpHargaSatuan = (float)$hitem['persenuphargasatuan'];
                    }
                }
                $results[] = array(
                    'norec' => $item->norec,
                    'objectprodukfk' => $item->objectprodukfk,
                    'tgl' => $item->tgl,
                    'objectasalprodukfk' => $item->objectasalprodukfk,
                    'asalproduk' => $item->asalproduk,
                    'harganetto' => $item->harganetto,
                    'hargadiscount' => $item->hargadiscount,
                    'hargajual' => (float)$item->harganetto + (((float)$item->harganetto * (float)$persenUpHargaSatuan) / 100),
                    'persenhargajualproduk' => $persenUpHargaSatuan,
                    'qtyproduk' => (float)$item->qtyproduk,
                    'objectruanganfk' => $item->objectruanganfk,
                    'nostrukterimafk' => $item->nostrukterimafk,
                    'tglkadaluarsa' => $item->tglkadaluarsa,
                );
            }
        }
        // ### END-FIFO ### //

        // ### Harga Tertinggi ### //
        if ($strSistemHargaNetto == 3) {
            $SistemHargaNetto = 'Harga Tertinggi';
            if ($strMetodeAmbilHargaNetto == 1) {//HN1
                $strHN = 'spd.harganetto1';
                $MetodeAmbilHargaNetto = 'HN1';
            }
            if ($strMetodeAmbilHargaNetto == 2) {//HN2
                $strHN = 'spd.harganetto2';
                $MetodeAmbilHargaNetto = 'HN2';
            }

            if ($strMetodeStokHargaNetto == 1) {//FIFO
                $strMSHT = 'sk.tglstruk';
                $MetodeStokHargaNetto = 'FIFO';
            }
            if ($strMetodeStokHargaNetto == 2) {//LIFO
                $strMSHT = '';
                $MetodeStokHargaNetto = 'LIFO';
            }
            if ($strMetodeStokHargaNetto == 3) {//FEFO
                $strMSHT = 'spd.tglkadaluarsa';
                $MetodeStokHargaNetto = 'FEFO';
            }
            if ($strMetodeStokHargaNetto == 4) {//LEFO
                $strMSHT = '';
                $MetodeStokHargaNetto = 'LEFO';
            }
            if ($strMetodeStokHargaNetto == 5) {//Summary
                $strMSHT = '';
                $MetodeStokHargaNetto = 'Summary';
            }
            $maxHarga = DB::select(DB::raw("select $strHN as harga
                from transaksistoktr as spd
                inner JOIN strukpelayanantr as sk on sk.norec=spd.nostrukterimafk
                where spd.koders = $idProfile and spd.produkidfk =:produkId and spd.ruanganidfk =:ruanganid"),
                array(
                    'produkId' => $request['produkfk'],
                    'ruanganid' => $request['ruanganfk'],
                )
            );
            $hargaTertinggi = 0;
            foreach ($maxHarga as $item) {
                if ($hargaTertinggi < (float)$item->harga) {
                    $hargaTertinggi = (float)$item->harga;
                }
            }

            $result = DB::select(DB::raw("select sk.norec,spd.produkidfk as objectprodukfk, $strMSHT as tgl,spd.asalprodukidfk as objectasalprodukfk,$hargaTertinggi as harganetto ,
                        $hargaTertinggi  as hargajual,spd.hargadiscount,sum(spd.qtyproduk) as qtyproduk,spd.ruanganidfk as objectruanganfk,ap.asalproduk,spd.nostrukterimafk,
                        spd.tglkadaluarsa
                from transaksistoktr as spd
                inner JOIN strukpelayanantr as sk on sk.norec=spd.nostrukterimafk
                inner JOIN asalprodukmt as ap on ap.id=spd.asalprodukidfk
                where spd.koders = $idProfile and spd.produkidfk =:produkId and spd.ruanganidfk =:ruanganid
                group by sk.norec,spd.produkidfk, $strMSHT,spd.asalprodukidfk,
                        spd.hargadiscount,
                spd.ruanganidfk,ap.asalproduk,spd.nostrukterimafk
                order By $strMSHT"),
                array(
                    'produkId' => $request['produkfk'],
                    'ruanganid' => $request['ruanganfk'],
                )
            );

            $persenUpHargaSatuan = 0;
            foreach ($result as $item) {
                foreach ($persenHargaJualProduk as $hitem) {
                    if ((float)$hitem['rangemin'] < (float)$item->harganetto && (float)$hitem['rangemax'] > (float)$item->harganetto) {
                        $persenUpHargaSatuan = (float)$hitem['persenuphargasatuan'];
                    }
                }
                $results[] = array(
                    'norec' => $item->norec,
                    'objectprodukfk' => $item->objectprodukfk,
                    'tgl' => $item->tgl,
                    'objectasalprodukfk' => $item->objectasalprodukfk,
                    'asalproduk' => $item->asalproduk,
                    'harganetto' => $item->harganetto,
                    'hargadiscount' => $item->hargadiscount,
                    'hargajual' => (float)$item->harganetto + (((float)$item->harganetto * (float)$persenUpHargaSatuan) / 100),
                    'persenhargajualproduk' => $persenUpHargaSatuan,
                    'qtyproduk' => (float)$item->qtyproduk,
                    'objectruanganfk' => $item->objectruanganfk,
                    'nostrukterimafk' => $item->nostrukterimafk,
                    'tglkadaluarsa' => $item->tglkadaluarsa,
                );
            }
        }
        // ### END-Harga Tertinggi ### //

        // ### Harga Terakhir ### //
        if ($strSistemHargaNetto == 7) {
            $SistemHargaNetto = 'Harga Terakhir';
            if ($strMetodeAmbilHargaNetto == 1) {//HN1
                $strHN = 'spd.harganetto1';
                $MetodeAmbilHargaNetto = 'HN1';
            }
            if ($strMetodeAmbilHargaNetto == 2) {//HN2
                $strHN = 'spd.harganetto2';
                $MetodeAmbilHargaNetto = 'HN2';
            }

            if ($strMetodeStokHargaNetto == 1) {//FIFO
                $strMSHT = 'sk.tglstruk';
                $MetodeStokHargaNetto = 'FIFO';
            }
            if ($strMetodeStokHargaNetto == 2) {//LIFO
                $strMSHT = 'sk.tglstruk desc';
                $MetodeStokHargaNetto = 'LIFO';
            }
            if ($strMetodeStokHargaNetto == 3) {//FEFO
                $strMSHT = 'spd.tglkadaluarsa';
                $MetodeStokHargaNetto = 'FEFO';
            }
            if ($strMetodeStokHargaNetto == 4) {//LEFO
                $strMSHT = 'spd.tglkadaluarsa desc';
                $MetodeStokHargaNetto = 'LEFO';
            }
            if ($strMetodeStokHargaNetto == 5) {//Summary
                $strMSHT = '';
                $MetodeStokHargaNetto = 'Summary';
            }
            $maxHarga = DB::select(DB::raw("select spd.tglpelayanan, $strHN as harga
                from transaksistoktr as spd
                inner JOIN strukpelayanantr as sk on sk.norec=spd.nostrukterimafk
                where spd.koders = $idProfile and spd.produkidfk =:produkId "),
                array(
                    'produkId' => $request['produkfk'],
                )
            );
            $hargaTerakhir = 0;
            $tgl = date('2000-01-01 00:00');
            foreach ($maxHarga as $item) {
                if ($tgl < $item->tglpelayanan) {
                    $tgl = $item->tglpelayanan;
                    $hargaTerakhir = (float)$item->harga;
                }
            }
            $result = [];
            $result = DB::select(DB::raw("select sk.norec,spd.produkidfk as objectprodukfk, $strMSHT as tgl,spd.asalprodukidfk as objectasalprodukfk,$hargaTerakhir as harganetto ,
                        $hargaTerakhir  as hargajual,spd.hargadiscount,spd.nostrukterimafk,
                sum(spd.qtyproduk) as qtyproduk,spd.ruanganidfk as objectruanganfk,ap.asalproduk,spd.tglkadaluarsa
                from transaksistoktr as spd
                inner JOIN strukpelayanantr as sk on sk.norec=spd.nostrukterimafk
                inner JOIN asalprodukmt as ap on ap.id=spd.asalprodukidfk
                where spd.koders = $idProfile and spd.produkidfk =:produkId and spd.ruanganidfk =:ruanganid and spd.qtyproduk > 0
                group by sk.norec,spd.produkidfk, $strMSHT, spd.asalprodukidfk,
                        spd.hargadiscount,
                spd.ruanganidfk,ap.asalproduk,spd.nostrukterimafk
                order By $strMSHT"),
                array(
                    'produkId' => $request['produkfk'],
                    'ruanganid' => $request['ruanganfk'],
                )
            );
            $results = [];
            $persenUpHargaSatuan = 0;
            foreach ($result as $item) {
                foreach ($persenHargaJualProduk as $hitem) {
                    if ((float)$hitem['rangemin'] < (float)$item->harganetto && (float)$hitem['rangemax'] > (float)$item->harganetto) {
                        $persenUpHargaSatuan = (float)$hitem['persenuphargasatuan'];
                    }
                }
                $results[] = array(
                    'norec' => $item->norec,
                    'objectprodukfk' => $item->objectprodukfk,
                    'tgl' => $item->tgl,
                    'objectasalprodukfk' => $item->objectasalprodukfk,
                    'asalproduk' => $item->asalproduk,
                    'harganetto' => (float)$item->harganetto,//$item->harganetto,
                    'hargadiscount' => $item->hargadiscount,
                    'hargajual' => (float)$item->harganetto + (((float)$item->harganetto * (float)$persenUpHargaSatuan) / 100),
                    'persenhargajualproduk' => $persenUpHargaSatuan,
                    'qtyproduk' => (float)$item->qtyproduk,
                    'objectruanganfk' => $item->objectruanganfk,
                    'nostrukterimafk' => $item->nostrukterimafk,
                    'tglkadaluarsa' => $item->tglkadaluarsa,
                );
            }
        }
        // ### END-Harga Terakhir ### //

        $jmlstok = 0;
        foreach ($result as $item) {
            $jmlstok = $jmlstok + $item->qtyproduk;
        }

//        $cekConsis = DB::select(DB::raw("select * from his_obat_ms_t where hobatid=:produkfk;"),
//            array(
//                'produkfk' => $request['produkfk'],
//            )
//        );
        $cekConsis =[];
        $cekKekuatanSupranatural = DB::select(DB::raw("

            select pr.kekuatan,sdn.name as sediaan from pelayananmt as pr
            inner join sediaanmt as sdn on sdn.id=pr.sediaanidfk
            where pr.koders = $idProfile and pr.id=:produkfk;

            "),
            array(
                'produkfk' => $request['produkfk'],
            )
        );
        $kekuatan = 0;
        $sediaan = 0;
        if (count($cekKekuatanSupranatural) > 0) {
            $kekuatan = (float)$cekKekuatanSupranatural[0]->kekuatan;
            $sediaan = $cekKekuatanSupranatural[0]->sediaan;
            if ($kekuatan == null) {
                $kekuatan = 0;
            }
        }


        $result = array(
            'detail' => $results,
            'jmlstok' => $jmlstok,
            'kekuatan' => $kekuatan,
            'sediaan' => $sediaan,
            'sistemharganetto' => $SistemHargaNetto,
            'metodeambilharganetto' => $MetodeAmbilHargaNetto,
            'metodestokharganetto' => $MetodeStokHargaNetto,
            'consis' => count($cekConsis),
            'message' => 'as@epic',
        );
        return $this->respond($result);
    }

    public function getJenisObat(Request $request)
    {

        $data = [];
        if (isset($request['jrid']) && $request['jrid'] != "" && $request['jrid'] != "undefined" && $request['jrid'] != 'null') {
            $data = \DB::table('jenisracikanmt as jr')
                ->select('jr.id', 'jr.jenisracikan');
            $data = $data->where('jr.id', $request['jrid']);
            $data = $data->get();
        }

        $result = array(
            'data' => $data,
            'message' => 'as@epic',
        );

        return $this->respond($result);
    }
}
