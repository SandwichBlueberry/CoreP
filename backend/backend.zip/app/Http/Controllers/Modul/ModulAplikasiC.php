<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 7/31/2019
 * Time: 4:42 PM
 */

namespace App\Http\Controllers\Modul;

use App\Http\Controllers\ApiController;
use App\Master\MapLoginUserToModulAplikasi;
use App\Master\MapObjekModulAplikasiToModulAplikasi;
use App\Master\WaktuLogin;
use App\Master\ModulAplikasi;
use App\Master\ObjekModulAplikasi;
use App\Web\LoginUser;
use Illuminate\Http\Request;
use App\Traits\Valet;
use DB;

class ModulAplikasiC extends ApiController
{

    use Valet;

    public function __construct()
    {
        parent::__construct($skip_authentication = false);
    }

    public function getMenu(Request $request)
    {
        $dataraw3 = [];
        $dataRaw = \DB::table('objekmodulaplikasi_s as oma')
            ->join('mapobjekmodulaplikasitomodulaplikasi_s as acdc', 'acdc.objekmodulaplikasiid', '=', 'oma.id')
            ->join('maploginusertomodulaplikasi_s as maps',
                function ($join) {
                    $join->on('maps.objectmodulaplikasifk', '=', 'acdc.modulaplikasiid');
                })
//				'maps.objectmodulaplikasifk', '=', 'acdc.modulaplikasiid')
            ->join('modulaplikasi_s as ma', 'ma.id', '=', 'acdc.modulaplikasiid')
//            ->where('oma.kdprofile', $kdProfile)
            ->where('oma.statusenabled', true)
            ->where('ma.reportdisplay', 'Menu')
            ->where('maps.objectloginuserfk', $request['idUser'])
            ->select('oma.id', 'oma.kdobjekmodulaplikasihead', 'oma.objekmodulaplikasi', 'oma.alamaturlform', 'ma.modulaplikasi',
                'acdc.modulaplikasiid', 'oma.kodeexternal')
            ->groupBy('oma.id', 'oma.kdobjekmodulaplikasihead', 'oma.objekmodulaplikasi', 'oma.alamaturlform', 'ma.modulaplikasi',
                'acdc.modulaplikasiid', 'oma.kodeexternal', 'oma.nourut')
            ->orderBy('oma.nourut');
        $dataRaw = $dataRaw->get();
        foreach ($dataRaw as $dataRaw2) {
//                if ((integer)$dataRaw2->id < 100) {
            if ($dataRaw2->kdobjekmodulaplikasihead == null) {
                if ($dataRaw2->alamaturlform != null || $dataRaw2->alamaturlform != '') {
                    $dataraw3[] = array(
                        'id' => $dataRaw2->id,
                        'parent_id' => 0,
                        'icon' => 'pi pi-fw pi-chevron-circle-right',
                        'label' => $dataRaw2->objekmodulaplikasi,
                        'routerLink' =>  [str_replace('#', '', $dataRaw2->alamaturlform)]
                    );
                } else {
                    $dataraw3[] = array(
                        'id' => $dataRaw2->id,
                        'parent_id' => 0,
                        'icon' => 'pi pi-fw pi-align-center',
                        'label' => $dataRaw2->objekmodulaplikasi,

                    );
                }

            } else {
                if ($dataRaw2->kdobjekmodulaplikasihead != null) {
                    if ($dataRaw2->alamaturlform != null || $dataRaw2->alamaturlform != '') {
                        $dataraw3[] = array(
                            'id' => $dataRaw2->id,
                            'parent_id' => $dataRaw2->kdobjekmodulaplikasihead,
                            'label' => $dataRaw2->objekmodulaplikasi,
                            'icon' => 'pi pi-fw pi-chevron-circle-right',
                            'routerLink' => [str_replace('#', '', $dataRaw2->alamaturlform)]
                        );
                    } else {
                        $dataraw3[] = array(
                            'id' => $dataRaw2->id,
                            'parent_id' => $dataRaw2->kdobjekmodulaplikasihead,
                            'label' => $dataRaw2->objekmodulaplikasi,
                            'icon' => 'pi pi-fw pi-align-center',
                        );
                    }
                } else {
                    if ($dataRaw2->modulaplikasiid == $request['id']) {
                        if ($dataRaw2->alamaturlform != null || $dataRaw2->alamaturlform != '') {
                            $dataraw3[] = array(
                                'id' => $dataRaw2->id,
                                'parent_id' => $dataRaw2->kdobjekmodulaplikasihead,
                                'label' => $dataRaw2->objekmodulaplikasi,
                                'icon' => 'pi pi-fw pi-chevron-circle-right',
                                'routerLink' =>  [str_replace('#', '', $dataRaw2->alamaturlform)]
                            );
                        } else {
                            $dataraw3[] = array(
                                'id' => $dataRaw2->id,
                                'parent_id' => $dataRaw2->kdobjekmodulaplikasihead,
                                'label' => $dataRaw2->objekmodulaplikasi,
                                'icon' => 'pi pi-fw pi-align-center',
                            );
                        }
                    }
                }
            }
        }
        $data = $dataraw3;
        function recursiveElements($data)
        {
            $elements = [];
            $tree = [];
            foreach ($data as &$element) {
                $id = $element['id'];
                $parent_id = $element['parent_id'];

                $elements[$id] = &$element;
                if (isset($elements[$parent_id])) {
                    $elements[$parent_id]['items'][] = &$element;
                } else {
                    if ($parent_id <= 10) {
                        $tree[] = &$element;
                    }
                }
            }
            return $tree;
        }

        $data = recursiveElements($data);

        return $this->respond($data);
    }

}
