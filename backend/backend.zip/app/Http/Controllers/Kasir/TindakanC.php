<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 12/04/2021
 * Time: 10:40 AM
 */

namespace App\Http\Controllers\Kasir;

use App\Http\Controllers\ApiController;
use App\Master\SettingDataFixed;
use App\Transaksi\AntrianPasienDiperiksa;
use App\Transaksi\LoggingUser;
use App\Transaksi\PasienDaftar;
use App\Transaksi\PelayananPasien;
use App\Transaksi\PelayananPasienDelete;
use App\Transaksi\PelayananPasienDetail;
use App\Transaksi\PelayananPasienPetugas;
use App\Transaksi\PelayananPasienTidakTerklaim;
use App\Transaksi\PelayananPasienTidakTerklaimDelete;
use App\Transaksi\PelayananPasienMutu;
use Illuminate\Http\Request;
use DB;

//use App\Pegawai\ModulAplikasi;
//use App\Pegawai\MapObjekModulToKelompokUser;
//use App\Pegawai\MapObjekModulAplikasiToModulAplikasi;
//use App\Pegawai\ObjekModulAplikasi;
//use App\Master\KelompokUser;

use App\Transaksi\StrukOrder;
use App\Transaksi\OrderPelayanan;
use App\Transaksi\OrderProduk;
use App\Master\Pegawai;
use App\Traits\Valet;
use phpDocumentor\Reflection\Types\Null_;
use Webpatser\Uuid\Uuid;

class TindakanC extends ApiController
{

    use Valet;

    public function __construct()
    {
        parent::__construct($skip_authentication = false);
    }

    public function getTindakanPart(Request $request)
    {
        $kdProfile = $this->getDataKdProfile($request);
        $idProfile = (int)$kdProfile;
        //TODO : GET LIST TINDAKAN
        $req = $request->all();
        $data = \DB::table('mappelayananruanganmt as mpr')
            ->join('pelayananmt as prd', 'prd.id', '=', 'mpr.produkidfk')
            ->select('mpr.produkidfk as id', 'prd.namaproduk',
                'mpr.ruanganidfk',
                'prd.namaproduk'
            )
            ->where('mpr.koders', $idProfile)
            ->where('mpr.ruanganidfk', $request['idRuangan'])
            ->where('mpr.aktif', true)
            ->where('prd.aktif', true);
        if (isset($req['filter']['filters'][0]['value']) &&
            $req['filter']['filters'][0]['value'] != "" &&
            $req['filter']['filters'][0]['value'] != "undefined") {
            $data = $data
                ->where('prd.namaproduk', 'ilike', '%' . $req['filter']['filters'][0]['value'] . '%');
        }
        if(isset($req['idProduk']) &&
            $req['idProduk']!="" &&
            $req['idProduk']!="undefined"){
            $data = $data
                ->where('prd.id','=',$req['idProduk']);
        }
        if (isset($req['namaproduk']) &&
            $req['namaproduk'] != "" &&
            $req['namaproduk'] != "undefined") {
            $data = $data
                ->where('prd.namaproduk', 'ilike', '%' . $req['namaproduk'] . '%');
        }
        $data = $data->orderBy('prd.namaproduk', 'ASC');
        $data = $data->take(15);
        $data = $data->get();
        return $this->respond($data);
    }

    public function getCombo(Request $request)
    {
        $kdProfile = $this->getDataKdProfile($request);
        $idProfile = (int)$kdProfile;
        $jenisPelaksana = \DB::table('jenispetugaspelaksanamt as jpp')
            ->where('jpp.aktif', true)
            ->orderBy('jpp.jenispetugaspe')
            ->get();
        $dataTarifAdminCito = $this->settingDataFixed('tarifadmincito', $idProfile);
        $result = array(
            'jenispelaksana' => $jenisPelaksana,
            'tarifcito' => $dataTarifAdminCito,
            'message' => 'ramdanegie',
        );
        return $this->respond($result);
    }

    public function getPegawaiByJenisPetugasPe(Request $request)
    {
        $kdProfile = $this->getDataKdProfile($request);
        $idProfile = (int)$kdProfile;
        $data = \DB::table('mapjenispetugasptojenispegawaimt as mpp')
            ->join('jenispegawaimt as jp', 'jp.id', '=', 'mpp.jenispegawaiidfk')
            ->join('pegawaimt as pg', 'pg.objectjenispegawaifk', '=', 'jp.id')
            ->join('jenispetugaspelaksanamt as jpp', 'jpp.id', '=', 'mpp.jenispetugaspeidfk')
            ->select('mpp.jenispegawaiidfk', 'jp.jenispegawai', 'mpp.jenispetugaspeidfk', 'jpp.jenispetugaspe',
                'pg.namalengkap', 'pg.id'
            )->groupBy('mpp.jenispegawaiidfk', 'jp.jenispegawai', 'mpp.jenispetugaspeidfk', 'jpp.jenispetugaspe',
                'pg.namalengkap', 'pg.id'
            )
            ->where('mpp.koders', $idProfile)
            ->where('mpp.jenispetugaspeidfk', $request['idJenisPetugas'])
            ->where('mpp.aktif', true)
            ->where('pg.aktif', true)
            ->where('jpp.aktif', true);
        if(isset($request['namalengkap']) && $request['namalengkap']!=''){
            $data = $data->where('pg.namalengkap', 'ilike','%'.$request['namalengkap'].'%');
        }
        $data = $data->orderBy('pg.namalengkap', 'ASC');
        $data = $data->get();

        $result = array(
            'jenispelaksana' => $data,
            'message' => 'ramdanegie',
        );

        return $this->respond($result);
    }

    public function saveTindakan(Request $request)
    {
        //TODO : SAVE TINDAKAN
        DB::beginTransaction();
        $kdProfile = $this->getDataKdProfile($request);
        $idProfile = (int)$kdProfile;
        try{

        $antrian = AntrianPasienDiperiksa::where('norec', $request['pelayananpasien'][0]['noregistrasifk'])
            ->update([
                'ispelayananpasien' => true
            ]);
        $totalJasa = 0;
        $totJasa = 0;
        $penjumlahanJasa = 0;
        $penjumlahanJasaTuslah = 0;
        foreach ($request['pelayananpasien'] as $item) {
            $totJasa = 0;
            $totalJasa = 0;
            $penjumlahanJasa = 0;
            $penjumlahanJasaTuslah = 0;
            $PelPasien = new PelayananPasien();
            $PelPasien->norec = $PelPasien->generateNewId();
            $PelPasien->koders = $idProfile;
            $PelPasien->aktif = true;
            $PelPasien->daftarpasienruanganfk = $item['noregistrasifk'];
            $PelPasien->tglregistrasi = $item['tglregistrasi'];
            $PelPasien->hargadiscount = $item['diskon']; //0;
            $PelPasien->hargajual = $item['hargajual'];
            $PelPasien->hargasatuan = $item['hargasatuan'];
            $PelPasien->jumlah = $item['jumlah'];
            $PelPasien->kelasidfk = $item['kelasfk'];
            $PelPasien->kdkelompoktransaksi = 1;
            if (isset($item['keterangan'])) {
                $PelPasien->keteranganlain = $item['keterangan'];
            }
            $PelPasien->piutangpenjamin = 0;
            $PelPasien->piutangrumahsakit = 0;
            $PelPasien->produkidfk = $item['produkfk'];
            $PelPasien->stock = 1;
            $PelPasien->tglpelayanan = $item['tglpelayanan'];
            $PelPasien->harganetto = $item['harganetto'];
            $PelPasien->iscito = $item['iscito'];
            if (isset($item['isparamedis'])) {
                $PelPasien->isparamedis = $item['isparamedis'];
            }
            if (isset($item['jenispelayananfk'])) {
                $PelPasien->jenispelayananidfk = $item['jenispelayananfk'];
            }
            $PelPasien->save();
            $PPnorec = $PelPasien->norec;

            $new_PPP = $item['pelayananpetugas'];
            foreach ($new_PPP as $itemPPP) {
                $detailItemPPP = $itemPPP['listpegawai'];
                foreach ($detailItemPPP as $detailItemPPPz) {
                    $PelPasienPetugas = new PelayananPasienPetugas();
                    $PelPasienPetugas->norec = $PelPasienPetugas->generateNewId();
                    $PelPasienPetugas->koders = $idProfile;
                    $PelPasienPetugas->aktif = true;
                    $PelPasienPetugas->nomasukidfk = $item['noregistrasifk'];
                    $PelPasienPetugas->jenispetugaspeidfk = $itemPPP['objectjenispetugaspefk'];
                    if ($detailItemPPPz == 'undefined') {
                        $PelPasienPetugas->pegawaiidfk = null;
                    } else {
                        $PelPasienPetugas->pegawaiidfk = $detailItemPPPz['id'];
                    }
                    $PelPasienPetugas->transaksipasienfk = $PPnorec;
                    $PelPasienPetugas->save();
                    $PPPnorec = $PelPasienPetugas->norec;
                }
            }
            //TODO : TARIFF UP TUSLAH
            $dataTuslah = $this->settingDataFixed('PersenUpTuslah',$idProfile);
            //END TARIFF UP TUSLAH
            foreach ($item['komponenharga'] as $itemKomponen) {
                $PelPasienDetail = new PelayananPasienDetail();
                $PelPasienDetail->norec = $PelPasienDetail->generateNewId();
                $PelPasienDetail->koders = $idProfile;
                $PelPasienDetail->aktif = true;
                $PelPasienDetail->daftarpasienruanganfk = $item['noregistrasifk'];
                $PelPasienDetail->aturanpakai = '-';
                $PelPasienDetail->hargadiscount = $item['diskon']; //0;
                $PelPasienDetail->hargajual = $itemKomponen['hargasatuan'];
                $PelPasienDetail->hargasatuan = $itemKomponen['hargasatuan'];
                $PelPasienDetail->jumlah = 1;
                $PelPasienDetail->keteranganlain = '-';
                $PelPasienDetail->keteranganpakai2 = '-';
                $PelPasienDetail->komponenhargaidfk = $itemKomponen['komponenhargaidfk'];
                $PelPasienDetail->transaksipasienfk = $PPnorec;
                $PelPasienDetail->piutangpenjamin = 0;
                $PelPasienDetail->piutangrumahsakit = 0;
                $PelPasienDetail->produkidfk = $item['produkfk'];
                $PelPasienDetail->stock = 1;
                $PelPasienDetail->tglpelayanan = $item['tglpelayanan'];
                $PelPasienDetail->harganetto = $itemKomponen['hargasatuan'];
                if ($itemKomponen['iscito'] == "1") {
                    if (!empty($dataTuslah)  && $dataTuslah> 0) {
                        $penjumlahanJasa = ($itemKomponen['hargasatuan'] - $item['diskon']) * $item['nilaicito'];
                        $penjumlahanJasaTuslah = (((float)$itemKomponen['hargasatuan'] * (int)$dataTuslah) / 100);
                        $totalJasa = $totalJasa + $penjumlahanJasa + $penjumlahanJasaTuslah;

                        $PelPasienDetail->jasa = $penjumlahanJasa + $penjumlahanJasaTuslah;
                    } else {
                        $penjumlahanJasa = ($itemKomponen['hargasatuan'] - $item['diskon']) * $item['nilaicito'];
                        $PelPasienDetail->jasa = $penjumlahanJasa;
                        $totalJasa = $totalJasa + $penjumlahanJasa;
                    }
                } else {
                    if (!empty($dataTuslah) && $dataTuslah > 0) {
                        $penjumlahanJasaTuslah = ((float)$itemKomponen['hargasatuan'] * (int)$dataTuslah) / 100;
                        $PelPasienDetail->jasa = $penjumlahanJasaTuslah;
                        $totalJasa = $totalJasa + $penjumlahanJasaTuslah;
                    } else {
                        $penjumlahanJasa = 0;
                        $PelPasienDetail->jasa = $penjumlahanJasa;
                        $totalJasa = $totalJasa + $penjumlahanJasa;
                    }
                }

                $PelPasienDetail->save();
                $PPDnorec = $PelPasienDetail->norec;
                $transStatus = 'true';
            }


            if ($item['iscito'] == 1) {
                $dataaa = PelayananPasienDetail::where('transaksipasienfk', $PPnorec)->get();
                foreach ($dataaa as $itemss) {
                    $totJasa = $totJasa + $itemss->jasa;
                }
                $dataJasa = PelayananPasien::where('norec', $PPnorec)
                    ->update([
                        'jasa' => $totalJasa
                    ]);
            }


            if (!empty($dataTuslah)  && $dataTuslah[0]->nilaifield > 0) {
                $dataJasa = PelayananPasien::where('norec', $PPnorec)
                    ->update([
                        'istuslah' => 1,
                        'jasa' => $totalJasa
                    ]);
            }

            if (isset($item['diskon'])) {
                if ($item['diskon'] != 0) {

                    $jasaPelayanan = $this->settingDataFixed('idKomponenJasaPelayanan',$idProfile);
                    if(!empty($jasaPelayanan)){
                        $data = PelayananPasienDetail::where('transaksipasienfk', $PPnorec)
                            ->where('komponenhargaidfk', (int)$jasaPelayanan)
                            ->update([
                                    'hargadiscount' => $item['diskon']]
                            );
                    }
                    $data2 = PelayananPasien::where('norec', $PPnorec)
                        ->update([
                                'hargadiscount' => $item['diskon']]
                        );
                }
            }
        }


            $transStatus = 'true';
        } catch (\Exception $e) {
        $transStatus = 'false';
        }

        if ($transStatus == 'true') {
            $transMessage = "Simpan Pelayanan Pasien";
            DB::commit();
            $result = array(
                'status' => 201,
                'message' => $transMessage,
                'dataPP' => $PelPasien,
                'dataPPD' => $PelPasienDetail,
                'dataTuslah' => $dataTuslah,
                'as' => 'er@epic',
                'edited' => 'ea@epic',
                'as2' => 'as@epic',
            );
        } else {
            $transMessage = "Simpan Pelayanan Gagal";
            DB::rollBack();
            $result = array(
                'status' => 400,
                'message' => $transMessage,
                'as' => 'ramdanegie',
            );
        }
        return $this->setStatusCode($result['status'])->respond($result, $transMessage);
//        return $this->respond($requestAll);
    }

    public function getKomponenHarga(Request $request)
    {
        $kdProfile = $this->getDataKdProfile($request);
        $idProfile = (int)$kdProfile;
        //TODO :GET HARGA & HARGA KOMPONEN
        $data = \DB::table('tarifpelayanandmt as hnp')
            ->join('mappelayananruanganmt as mpr', 'mpr.produkidfk', '=', 'hnp.produkidfk')
            ->join('pelayananmt as prd', 'prd.id', '=', 'mpr.produkidfk')
            ->join('komponentarifmt as kh', 'kh.id', '=', 'hnp.komponenhargaidfk')
            ->join('kelasmt as kls', 'kls.id', '=', 'hnp.kelasidfk')
            ->join('ruanganmt as ru', 'ru.id', '=', 'mpr.ruanganidfk')
            ->select(DB::raw("
                hnp.komponenhargaidfk,kh.komponentarif as komponenharga,CAST(hnp.hargasatuan AS float8) AS hargasatuan,mpr.produkidfk,kh.iscito
            "))
            ->where('mpr.ruanganidfk', $request['idRuangan'])
            ->where('hnp.kelasidfk', $request['idKelas'])
            ->where('mpr.produkidfk', $request['idProduk'])
            ->where('hnp.jenispelayananidfk', $request['idJenisPelayanan'])
            ->where('mpr.aktif', true)
            ->where('hnp.aktif', true)
            // ->where('sk.statusenabled',true)
            ->where('prd.aktif', true)
            ->where('hnp.koders', $idProfile);
        $data = $data->distinct();
        $data = $data->get();


        $data2 = \DB::table('tarifpelayananmt as hnp')
            ->join('mappelayananruanganmt as mpr', 'mpr.produkidfk', '=', 'hnp.produkidfk')
            ->join('pelayananmt as prd', 'prd.id', '=', 'mpr.produkidfk')
            ->join('kelasmt as kls', 'kls.id', '=', 'hnp.kelasidfk')
            ->join('ruanganmt as ru', 'ru.id', '=', 'mpr.ruanganidfk')
            ->join('suratkeputusanmt as sk', 'hnp.suratkeputusanidfk', '=', 'sk.id')
            ->select('mpr.produkidfk', 'prd.id', 'prd.namaproduk', 'hnp.hargasatuan', 'hnp.kelasidfk',
                'kls.namakelas', 'mpr.ruanganidfk', 'ru.namaruangan',
                'prd.namaproduk'
            )
            ->where('mpr.ruanganidfk', $request['idRuangan'])
            ->where('hnp.kelasidfk', $request['idKelas'])
            ->where('mpr.produkidfk', $request['idProduk'])
            ->where('hnp.jenispelayananidfk', $request['idJenisPelayanan'])
            ->where('hnp.aktif', true)
            ->where('sk.aktif', true)
            ->where('mpr.aktif', true)
            ->where('hnp.koders', $idProfile)
            ->where('prd.aktif', true);
        $data2 = $data2->distinct();
        $data2 = $data2->get();

        $result = array(
            'data' => $data,
            'data2' => $data2,
            'message' => 'ramdanegie',
            'edited' => 'as@epic',
        );

        return $this->respond($result);
    }
}
