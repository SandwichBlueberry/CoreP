<?php
/**
 * Created by PhpStorm.
 * User: nengepic
 * Date: 09/08/2019
 * Time: 13:36
 */

namespace App\Http\Controllers\SysAdmin;

use App\Http\Controllers\ApiController;
use App\Master\Agama;
use App\Master\Evaluasi;
use App\Master\Implementasi;
use App\Master\Intervensi;
use App\Master\JenisKelamin;
use App\Master\Pendidikan;
use App\Master\StatusPerkawinan;
use App\Master\DiagnosaKeperawatan;
use App\Transaksi\MapLaporangKeuanganToLingkupPelayanan;
use App\Transaksi\MapRuanganToAdministrasi;
use App\Transaksi\MapRuanganToAkomodasi;
use App\Transaksi\PostingJurnal;
use App\Transaksi\PostingJurnalTransaksi;
use App\Transaksi\PostingJurnalTransaksiD;
use App\Transaksi\StrukPlanning;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Traits\Valet;
use DB;


use App\Transaksi\IdentifikasiPasien;
use App\Transaksi\PasienDaftar;

class GeneralC extends ApiController
{
    use Valet;

    public function __construct()
    {
        parent::__construct($skip_authentication = false);
    }

    public function getTerbilangGeneral($number)
    {
        $terbilang = $this->makeTerbilang($number);
        return $this->respond(array('terbilang' => $terbilang));
    }

    public function getStatusClosePeriksa($noregistrasi, Request $request)
    {
        $kdProfile = (int)$this->getDataKdProfile($request);
        $data = PasienDaftar::where('noregistrasi', $noregistrasi)->where('koders', $kdProfile)->first();
        $status = false;
        $tgl = null;
        if (!empty($data) && $data->isclosing != null) {
            $status = $data->isclosing;
            $tgl = $data->tglclosing;
        }
        $result = array(
            'status' => $status,
            'tglclosing' => $tgl,
            'message' => 'ramdan@epic',
        );
        return $this->respond($result);
    }

    public function getTindakanWithDetail(Request $request)
    {
        $kdProfile = (int)$this->getDataKdProfile($request);
        $detail = \DB::table('detailjenisprodukmt')
            ->select('id', 'detailjenisproduk')
            ->where('koders', $kdProfile)
            ->where('aktif', true)
            ->get();
        $data = \DB::table('mappelayananruanganmt as mpr')
            ->join('pelayananmt as prd', 'prd.id', '=', 'mpr.produkidfk')
            ->select('mpr.produkidfk as id', 'prd.namaproduk', 'prd.detailjenisprodukidfk as objectdetailjenisprodukfk',
                'mpr.ruanganidfk as objectruanganfk',
                'prd.namaproduk'
            )
            ->where('mpr.koders', $kdProfile)
            ->where('mpr.ruanganidfk', $request['idRuangan'])
            ->where('mpr.aktif', true)
            ->where('prd.aktif', true)
            ->orderBy('prd.namaproduk', 'ASC')
            ->get();
        $detail = $detail->toArray();
        foreach ($detail as $key => $value) {
            $value->details = [];
        }
        $i = 0;
        foreach ($detail as $value) {
            foreach ($data as $value2) {
                $value2->selected = false;
                $value2->name = $value2->namaproduk;
                if ($detail[$i]->id == $value2->objectdetailjenisprodukfk) {
                    $detail[$i]->details[] = $value2;//array('namaproduk' =>  $value2->namaproduk, );
                }
            }
            $i++;
        }
        for ($i = count($detail) - 1; $i >= 0; $i--) {
            if (count($detail[$i]->details) == 0) {
                array_splice($detail, $i, 1);
            }
        }
        $result = array(
            'data' => $data,
            'details' => $detail,
            'message' => 'ramdanegie',
        );

        return $this->respond($result);
    }
}
