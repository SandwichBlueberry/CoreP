<?php
/**
 * Created by PhpStorm.
 * User: Sany
 * Date: 11/28/2017
 * Time: 8:35 PM
 */

namespace App\Http\Controllers\SysAdmin;
use App\Http\Controllers\ApiController;
use App\Master\MapKelompokPasientoPenjamin;
use App\Master\Rekanan;
use App\Master\SettingDataFixed;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Traits\CrudMaster;
use App\Traits\Valet;

use App\Master\ChartOfAccount;
use DB;
use App\Traits\Dev\Designation;
use Date;

class SettingDataFixedC extends ApiController
{
    use CrudMaster;
    use Designation;
    use Valet;

    public function __construct()
    {
        parent::__construct($skip_authentication = false);
    }

    protected function getSettingDataFixedGeneric($namaField, Request $request){
        $kdProfile = (int) $this->getDataKdProfile($request);
        $set = SettingDataFixed::where('namafield', $namaField)->where('koders', $kdProfile)->first();
        return $set->nilaifield;
    }
}
