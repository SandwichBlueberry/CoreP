<?php


namespace App\Http\Controllers\Penunjang;


use App\Http\Controllers\ApiController;
use App\Master\Pasien;
use App\Traits\InternalList;
use App\Traits\PelayananPasienTrait;
use App\Traits\SettingDataFixedTrait;
use App\Traits\Valet;
use App\Transaksi\AntrianPasienDiperiksa;
use App\Transaksi\HasilPemeriksaanLab;
use App\Transaksi\HasilRadiologi;
use App\Transaksi\PasienDaftar;
use App\Transaksi\PelayananPasien;
use App\Transaksi\PelayananPasienDetail;
use App\Transaksi\PelayananPasienPetugas;
use App\Transaksi\StrukOrder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PenunjangC  extends ApiController
{
    use Valet, PelayananPasienTrait, SettingDataFixedTrait,InternalList;

    public function __construct()
    {
        parent::__construct($skip_authentication = false);
    }

    public function getDataComboPenunjang(Request $request)
    {
        $kdProfile = $this->getDataKdProfile($request);
        $dataLogin = $request->all();
        $dataPegawai = \DB::table('loginuser_s as lu')
            ->join('pegawaimt as pg', 'pg.id', '=', 'lu.objectpegawaifk')
            ->select('lu.objectpegawaifk', 'pg.namalengkap')
            ->where('lu.id', $dataLogin['userData']['id'])
            ->where('lu.kdprofile', (int)$kdProfile)
            ->first();

        $dataInstalasi = \DB::table('instalasimt as dp')
            ->where('dp.aktif', true)
            ->where('dp.koders', (int)$kdProfile)
            ->orderBy('dp.namadepartemen')
            ->get();

        $dataRuangan = \DB::table('ruanganmt as ru')
            ->where('ru.aktif', true)
            ->where('ru.koders', (int)$kdProfile)
            ->orderBy('ru.namaruangan')
            ->get();

        foreach ($dataInstalasi as $item) {
            $detail = [];
            foreach ($dataRuangan as $item2) {
                if ($item->id == $item2->instalasiidfk) {
                    $detail[] = array(
                        'id' => $item2->id,
                        'ruangan' => $item2->namaruangan,
                    );
                }
            }

            $dataDepartemen[] = array(
                'id' => $item->id,
                'departemen' => $item->namadepartemen,
                'ruangan' => $detail,
            );
        }

        $dataKelompok = \DB::table('kelompokpasienmt as kp')
            ->select('kp.id', 'kp.kelompokpasien')
            ->where('kp.aktif', true)
            ->orderBy('kp.kelompokpasien')
            ->get();

        $dataKelas = \DB::table('kelasmt as kl')
            ->select('kl.id', 'kl.namakelas')
            ->where('kl.aktif', true)
            ->orderBy('kl.id')
            ->get();

        $deptRanap = explode(',', $this->settingDataFixed('kdDepartemenNonRanap', $kdProfile));
        $kdDepartemenRawatInap = [];
        foreach ($deptRanap as $itemRanap) {
            $kdDepartemenRawatInap [] = (int)$itemRanap;
        }

        $dataRuanganNonInap = \DB::table('ruanganmt as ru')
            ->where('ru.aktif', true)
            ->where('ru.koders', (int)$kdProfile)
            ->whereIn('ru.instalasiidfk', $kdDepartemenRawatInap)
            ->orderBy('ru.namaruangan')
            ->get();

        $kdRanap = (int) $this->settingDataFixed('kdDepartemenRanap', $kdProfile);

        $dataDokter = \DB::table('pegawaimt as ru')
            ->select('ru.id','ru.namalengkap')
            ->where('ru.aktif', true)
            ->where('ru.objectjenispegawaifk', 1)
            ->where('ru.koders', (int)$kdProfile)
            ->orderBy('ru.namalengkap')
            ->get();

        $dataGolDarah = \DB::table('golongandarahmt as ru')
            ->select('ru.id','ru.golongandarah')
            ->where('ru.aktif', true)
            ->where('ru.koders', (int)$kdProfile)
            ->orderBy('ru.id')
            ->get();

        $result = array(
            'dataLogin' => $dataPegawai,
            'departemen' => $dataDepartemen,
            'kelompokpasien' => $dataKelompok,
            'datalogin' => $dataLogin,
            'kelas' => $dataKelas,
            'ruangannonianp' => $dataRuanganNonInap,
            'kdRanap' => $kdRanap,
            'dokter' => $dataDokter,
            'goldarah' => $dataGolDarah,
            'message' => 'ea@epc',
        );

        return $this->respond($result);
    }

    public function getDataRuangTujuanPenunjang(Request $request)
    {
        $kdProfile = $this->getDataKdProfile($request);
        $dataRuangan = \DB::table('ruanganmt as ru')
            ->select('ru.id','ru.namaruangan')
            ->where('ru.aktif', true)
            ->where('ru.koders', (int)$kdProfile);

        if (isset($request['keluseridfk'])){
            $dataRuangan = $dataRuangan->where('ru.kelompokuseridfk','=',$request['keluseridfk']);
        }

        $dataRuangan = $dataRuangan->orderBy('ru.namaruangan');
        $dataRuangan = $dataRuangan->get();

        $result = array(
            'ruangan' => $dataRuangan,
            'message' => 'ea@epc',
        );

        return $this->respond($result);
    }

    public function getDaftarOrderPenunjang(Request $request) {
        $kdProfile = (int) $this->getDataKdProfile($request);
        $dataLogin = $request->all();
        $result = [];
        if ($request['KelUser'] == "laboratorium") {
            $data = \DB::table('transaksiordertr as so')
                ->join('registrasipasientr as pd', 'pd.norec', '=', 'so.registrasipasienfk')
                ->leftjoin('strukpelayanantr as sps', 'sps.norec', '=', 'pd.nostruklastidfk')
                ->join('pasienmt as ps', 'ps.id', '=', 'pd.normidfk')
                ->leftJoin('jeniskelaminmt as klm', 'klm.id', '=', 'ps.jeniskelaminidfk')
                ->join('ruanganmt as ru', 'ru.id', '=', 'so.ruanganidfk')
                ->join('ruanganmt as ru2', 'ru2.id', '=', 'so.ruangantujuanidfk')
                ->join('instalasimt as dp', 'dp.id', '=', 'ru.instalasiidfk')
                ->join('instalasimt as dp2', 'dp2.id', '=', 'ru2.instalasiidfk')
                ->leftJoin('kelompokpasienmt as kps', 'kps.id', '=', 'pd.kelompokpasienlastidfk')
                ->join('kelasmt as kls', 'kls.id', '=', 'pd.kelasidfk')
                ->leftJoin('pegawaimt as pg', 'pg.id', '=', 'so.pegawaiorderidfk')
                ->Join('daftarpasienruangantr as apd', function($join){
                    $join->on('apd.registrasipasienfk','=','pd.norec');
                    $join->on('apd.ruanganidfk','=','pd.ruanganlastidfk');
                })
                ->select(DB::raw("
                     so.norec AS norec_so,pd.norec AS norec_pd,so.noorder,pd.noregistrasi,pd.tglregistrasi,pd.tglpulang,
                     ps.norm,ps.namapasien,kps.kelompokpasien,klm.jeniskelamin,ps.tgllahir,kps.kelompokpasien,dp.namadepartemen,
                     pd.kelasidfk,kls.namakelas,kls.id AS klsid,so.ruangantujuanidfk,so.ruanganidfk,
                     pd.kelompokpasienlastidfk,ru.instalasiidfk,ru2.instalasiidfk AS iddeptujuan,
                     so.pegawaiorderidfk,pg.namalengkap AS pegawaiorder,ru.namaruangan,ru.id AS ruid,ru2.namaruangan AS ruangantujuan,
                     so.tglorder,sps.nostruk,apd.norec AS norec_apd,so.keteranganlainnya,so.cito,
                     CASE WHEN so.statusorder IS NULL THEN 'MASUK' ELSE 'SELESAI' END AS status
                "))
                ->where('so.koders', $kdProfile)
                ->where('ru2.instalasiidfk',$this->settingDataFixed('kdDepartemenLab', $kdProfile))
                ->where('so.aktif',true) ;
            if (isset($request['isNotVerif']) && $request['isNotVerif'] != "" && $request['isNotVerif'] != "undefined") {
                if ($request['isNotVerif'] == true) {
                    $data = $data->whereNull('so.statusorder');
                }
            }
        }
        if ($request['KelUser'] == "radiologi") {
            $data = \DB::table('transaksiordertr as so')
                ->join('registrasipasientr as pd', 'pd.norec', '=', 'so.registrasipasienfk')
                ->leftjoin('strukpelayanantr as sps', 'sps.norec', '=', 'pd.nostruklastidfk')
                ->join('pasienmt as ps', 'ps.id', '=', 'pd.normidfk')
                ->leftJoin('jeniskelaminmt as klm', 'klm.id', '=', 'ps.jeniskelaminidfk')
                ->join('ruanganmt as ru', 'ru.id', '=', 'so.ruanganidfk')
                ->join('ruanganmt as ru2', 'ru2.id', '=', 'so.ruangantujuanidfk')
                ->join('instalasimt as dp', 'dp.id', '=', 'ru.instalasiidfk')
                ->join('instalasimt as dp2', 'dp2.id', '=', 'ru2.instalasiidfk')
                ->leftJoin('kelompokpasienmt as kps', 'kps.id', '=', 'pd.kelompokpasienlastidfk')
                ->join('kelasmt as kls', 'kls.id', '=', 'pd.kelasidfk')
                ->leftJoin('pegawaimt as pg', 'pg.id', '=', 'so.pegawaiorderidfk')
                ->leftJoin('ris_order as pp', 'pp.order_no', '=', 'so.noorder')
                ->Join('daftarpasienruangantr as apd', function($join){
                    $join->on('apd.registrasipasienfk','=','pd.norec');
                    $join->on('apd.ruanganidfk','=','pd.ruanganlastidfk');
                })
                ->select(DB::raw("
                         so.norec AS norec_so,pd.norec AS norec_pd,so.noorder,pd.noregistrasi,pd.tglregistrasi,
                         pd.tglpulang,ps.norm,ps.namapasien,kps.kelompokpasien,klm.jeniskelamin,ps.tgllahir,
                         kps.kelompokpasien,dp.namadepartemen,pd.kelasidfk,kls.namakelas,kls.id AS klsid,
                         so.ruangantujuanidfk,so.ruanganidfk,pd.kelompokpasienlastidfk,ru.instalasiidfk,
                         ru2.instalasiidfk AS iddeptujuan,so.pegawaiorderidfk,pg.namalengkap AS pegawaiorder,
                         so.tglorder,sps.nostruk,apd.norec AS norec_apd,ru.namaruangan,ru2.namaruangan AS ruangantujuan,
                         so.keteranganlainnya,so.cito,CASE WHEN so.statusorder IS NULL THEN 'MASUK' ELSE 'SELESAI' END AS status
                    "))
                ->where('so.koders', $kdProfile)
                ->where('ru2.instalasiidfk', $this->settingDataFixed('kdDepartemenRad', $kdProfile))
                ->where('so.aktif', true);
            if (isset($request['isNotVerif']) && $request['isNotVerif'] != "" && $request['isNotVerif'] != "undefined") {
                if ($request['isNotVerif'] == true) {
                    $data = $data->whereNull('so.statusorder');
                }
            }
        }
//        if ($request['KelUser'] == "elektromedik") {
//            $data = \DB::table('strukorder_t as so')
//                ->join('pasiendaftar_t as pd', 'pd.norec', '=', 'so.noregistrasifk')
//                ->leftjoin('strukpelayanan_t as sps', 'sps.norec', '=', 'pd.nostruklastfk')
//                ->join('pasien_m as ps', 'ps.id', '=', 'pd.nocmfk')
//                ->leftJoin('jeniskelamin_m as klm', 'klm.id', '=', 'ps.objectjeniskelaminfk')
//                ->join('ruangan_m as ru', 'ru.id', '=', 'so.objectruanganfk')
//                ->join('ruangan_m as ru2', 'ru2.id', '=', 'so.objectruangantujuanfk')
//                ->join('departemen_m as dp', 'dp.id', '=', 'ru.objectdepartemenfk')
//                ->join('departemen_m as dp2', 'dp2.id', '=', 'ru2.objectdepartemenfk')
//                ->leftJoin('kelompokpasien_m as kps', 'kps.id', '=', 'pd.objectkelompokpasienlastfk')
//                ->join('kelas_m as kls', 'kls.id', '=', 'pd.objectkelasfk')
//                ->leftJoin('pegawai_m as pg', 'pg.id', '=', 'so.objectpegawaiorderfk')
//                ->select('so.norec as norec_so', 'pd.norec as norec_pd', 'so.noorder', 'pd.noregistrasi', 'pd.tglregistrasi', 'pd.tglpulang', 'ps.nocm', 'ps.namapasien','kps.kelompokpasien',
//                    'klm.jeniskelamin', 'ps.tgllahir',
//                    'kps.kelompokpasien', 'dp.namadepartemen', 'pd.objectkelasfk', 'kls.namakelas', 'so.objectruangantujuanfk',
//                    'so.objectruanganfk', 'pd.objectkelompokpasienlastfk', 'ru.objectdepartemenfk', 'ru2.objectdepartemenfk as iddeptujuan',
//                    'so.objectpegawaiorderfk', 'pg.namalengkap as pegawaiorder', 'so.tglorder', 'sps.nostruk',
//                    'ru.namaruangan', 'ru2.namaruangan as ruangantujuan',
//                    'so.keteranganlainnya','so.cito',
//                    (DB::raw("case when so.statusorder is null then 'MASUK' else
//                                    'SELESAI' end as status")))
//                ->where('so.kdprofile', $kdProfile)
//                ->where('ru2.objectdepartemenfk', $this->settingDataFixed('kdDepartemenElektromedik', $kdProfile))
//                ->where('so.statusenabled', true);
//            if (isset($request['isNotVerif']) && $request['isNotVerif'] != "" && $request['isNotVerif'] != "undefined") {
//                if ($request['isNotVerif'] == true) {
//                    $data = $data->whereNull('so.statusorder');
//                }
//            }
//        }

        if ($request['KelUser'] == "bedah") {
            $data = \DB::table('transaksiordertr as so')
                ->join('registrasipasientr as pd', 'pd.norec', '=', 'so.registrasipasienfk')
                ->leftjoin('strukpelayanantr as sps', 'sps.norec', '=', 'pd.nostruklastidfk')
                ->join('pasienmt as ps', 'ps.id', '=', 'pd.normidfk')
                ->leftJoin('jeniskelaminmt as klm', 'klm.id', '=', 'ps.jeniskelaminidfk')
                ->join('ruanganmt as ru', 'ru.id', '=', 'so.ruanganidfk')
                ->join('ruanganmt as ru2', 'ru2.id', '=', 'so.ruangantujuanidfk')
                ->join('instalasimt as dp', 'dp.id', '=', 'ru.instalasiidfk')
                ->join('instalasimt as dp2', 'dp2.id', '=', 'ru2.instalasiidfk')
                ->leftJoin('kelompokpasienmt as kps', 'kps.id', '=', 'pd.kelompokpasienlastidfk')
                ->join('kelasmt as kls', 'kls.id', '=', 'pd.kelasidfk')
                ->leftJoin('pegawaimt as pg', 'pg.id', '=', 'so.pegawaiorderidfk')
                ->Join('daftarpasienruangantr as apd', function($join){
                    $join->on('apd.registrasipasienfk','=','pd.norec');
                    $join->on('apd.ruanganidfk','=','pd.ruanganlastidfk');
                })
                ->leftJoin('pegawaimt as pg2', 'pg2.id', '=', 'pd.pegawaiidfk')
                ->leftJoin('transaksipasientr as pp', 'pp.transaksiorderfk', '=', 'so.norec')
                ->select(DB::raw("
                    so.norec AS norec_so,pd.norec AS norec_pd,so.noorder,pd.noregistrasi,pd.tglregistrasi,pd.tglpulang,ps.norm,
                    ps.namapasien,kps.kelompokpasien,klm.jeniskelamin,ps.tgllahir,kps.kelompokpasien,dp.namadepartemen,pd.kelasidfk,
                    kls.namakelas,kls.id AS klsid,so.ruangantujuanidfk,so.ruanganidfk,pd.kelompokpasienlastidfk,ru.instalasiidfk,
                    ru2.instalasiidfk AS iddeptujuan,so.pegawaiorderidfk,pg.namalengkap AS pegawaiorder,so.tglorder,
                    ru.namaruangan,ru2.namaruangan AS ruangantujuan,so.tglpelayananakhir,pg2.namalengkap AS dpjp,
                    apd.norec AS norec_apd,so.cito,CASE WHEN pp.transaksiorderfk IS NULL THEN 'MASUK' ELSE 'Sudah Verifikasi' END AS status,
                  '' AS kddiagnosa
                "))
                ->where('so.koders', $kdProfile)
                ->where('ru2.instalasiidfk', $this->settingDataFixed('kdDepartemenOK', $kdProfile))
                ->where('so.aktif',true);

            if (isset($request['isNotVerif']) && $request['isNotVerif'] != "" && $request['isNotVerif'] != "undefined") {
                if ($request['isNotVerif'] == true) {
                    $data = $data->whereNull('so.statusorder');
                }
            }
        }
        if(isset($request['tglAwal']) && $request['tglAwal']!="" && $request['tglAwal']!="undefined"){
            $data = $data->where('so.tglorder','>=', $request['tglAwal']);
        }
        if(isset($request['tglAkhir']) && $request['tglAkhir']!="" && $request['tglAkhir']!="undefined"){
            $data = $data->where('so.tglorder','<=', $request['tglAkhir']);
        }
        if(isset($request['tglAwalOperasi']) && $request['tglAwalOperasi']!="" && $request['tglAwalOperasi']!="undefined"){
            $data = $data->where('so.tglpelayananakhir','>=', $request['tglAwalOperasi']);
        }
        if(isset($request['tglAkhirOperasi']) && $request['tglAkhirOperasi']!="" && $request['tglAkhirOperasi']!="undefined"){
            $tgl= $request['tglAkhirOperasi'];
            $data = $data->where('so.tglpelayananakhir','<=', $tgl);
        }
        if(isset($request['deptId']) && $request['deptId']!="" && $request['deptId']!="undefined"){
            $data = $data->where('ru.instalasiidfk','=', $request['deptId']);
        }
        if(isset($request['pegId']) && $request['pegId']!="" && $request['pegId']!="undefined"){
            $data = $data->where('so.pegawaiorderidfk','=', $request['pegId']);
        }
        if(isset($request['ruangId']) && $request['ruangId']!="" && $request['ruangId']!="undefined"){
            $data = $data->where('so.ruanganidfk','=', $request['ruangId']);
        }
        if(isset($request['ruangTujuanid']) && $request['ruangTujuanid']!="" && $request['ruangTujuanid']!="undefined"){
            $data = $data->where('so.ruangantujuanidfk','=', $request['ruangTujuanid']);
        }
        if(isset($request['kelId']) && $request['kelId']!="" && $request['kelId']!="undefined"){
            $data = $data->where('pd.kelompokpasienlastidfk','=', $request['kelId']);
        }
        if(isset($request['noregistrasi']) && $request['noregistrasi']!="" && $request['noregistrasi']!="undefined"){
            $data = $data->where('pd.noregistrasi','ilike','%'. $request['noregistrasi'].'%');
        }
        if(isset($request['nocm']) && $request['nocm']!="" && $request['nocm']!="undefined"){
            $data = $data->where('ps.norm','ilike','%'. $request['nocm'].'%');
        }
        if(isset($request['namapasien']) && $request['namapasien']!="" && $request['namapasien']!="undefined"){
            $data = $data->where('ps.namapasien','ilike','%'. $request['namapasien'].'%');
        }
        if(isset($request['noOrders']) && $request['noOrders']!="" && $request['noOrders']!="undefined"){
            $data = $data->where('so.noorder','ilike','%'. $request['noOrders'].'%');
        }
        if(isset($request['jmlRow']) && $request['jmlRow']!="" && $request['jmlRow']!="undefined"){
            $data = $data->take($request['jmlRow']);
        }
        $data = $data->orderBy('so.noorder','desc');
        $data = $data->distinct();
        $data = $data->get();

        $norecaPd = '';
        foreach ($data as $ob){
            $norecaPd = $norecaPd.",'".$ob->norec_apd . "'";
            $ob->kddiagnosa = '';
        }
        $norecaPd = substr($norecaPd, 1, strlen($norecaPd)-1);
        $diagnosa = [];
        if($norecaPd!= ''){
            $diagnosa = DB::select(DB::raw("
               select dg.kddiagnosa,dg.namadiagnosa,
                      dg.kddiagnosa || '~' || dg.namadiagnosa AS diagnosa,
                      ddp.daftarpasienruanganfk as norec_apd
               from diagnosapasienicdxtr as ddp              
               left join icdxmt as dg on ddp.jenisdiagnosaidfk = dg.id
               where ddp.daftarpasienruanganfk in ($norecaPd) and ddp.jenisdiagnosaidfk = 1"));
            $i = 0;
            foreach ($data as $h){
                foreach ($diagnosa as $d){
                    if($data[$i]->norec_apd == $d->norec_apd){
                        $data[$i]->kddiagnosa = $d->kddiagnosa;
                    }
                }
                $i++;
            }
        }

        $dataResult=array(
            'message' =>  'inhuman',
            'data' =>  $data,
        );
        return $this->respond($dataResult);
    }

    public function getDiagnosaRad( Request $request) {
        $kdProfile = (int) $this->getDataKdProfile($request);
        $data = \DB::table('registrasipasientr as pd')
            ->select(DB::raw("
                pd.noregistrasi,pd.tglregistrasi,apd.ruanganidfk,ru.namaruangan,apd.norec AS norec_apd,
			    ddp.icdxidfk,dg.kddiagnosa,dg.namadiagnosa,ddp.tglinputdiagnosa,ddp.jenisdiagnosaidfk,
			    jd.jenisdiagnosa,ddp.norec AS norec_detaildpasien,ddp.tglinputdiagnosa,
			    ddp.ketdiagnosis,dg.*,ddp.iskasusbaru,ddp.iskasuslama
            "))
            ->join('daftarpasienruangantr as apd','apd.registrasipasienfk','=','pd.norec')
            ->join('ruanganmt as ru','ru.id','=','apd.ruanganidfk')
            ->join ('diagnosapasienicdxtr as ddp','ddp.daftarpasienruanganfk','=','apd.norec')
            ->join ('icdxmt as dg','dg.id','=','ddp.icdxidfk')
            ->join ('jenisdiagnosamt as jd','jd.id','=','ddp.jenisdiagnosaidfk')
            ->where('pd.aktif', true)
            ->where('pd.koders',$kdProfile);

        if(isset($request['noReg']) && $request['noReg']!="" && $request['noReg']!="undefined"){
            $data = $data->where('pd.noregistrasi','=', $request['noReg']);
        };

        $data=$data->get();

        $result = array(
            'datas' => $data,
            'message' => 'giw',
        );
        return $this->respond($result);
    }

    public function getOrderPelayanan(Request $request) {
        $idkelas = $request['objectkelasfk'];
        $norec_so = $request['norec_so'];
        $kdProfile = (int) $this->getDataKdProfile($request);
        $so = StrukOrder::where('norec',$norec_so)->where('koders',$kdProfile)->first();
        $pasienDaftar = PasienDaftar::where('norec',$so->registrasipasienfk)
            ->where('koders',$kdProfile)
            ->first();
        $jp = (int)$pasienDaftar->jenispelayanan;
        $dataOrderPelayanan = \DB::select(DB::raw("
                select DISTINCT op.norec AS norec_op,pr. ID AS prid,pr.namaproduk,op.tglpelayanan,op.qtyproduk,
                     ru.namaruangan AS ruangantujuan,ru.instalasiidfk,op.strukorderfk,so.ruangantujuanidfk,
                     hnp.hargasatuan,kls.namakelas,dpm.namadepartemen,pps.norec AS norec_pp
                from transaksiorderdetailtr AS op
                left join transaksiordertr as so on so.norec = op.transaksiorderfk
                INNER JOIN pelayananmt as pr on pr.id = op.produkidfk
                left JOIN tarifpelayananmt as hnp on pr.id = hnp.produkidfk
                        and hnp.kelasidfk = '$idkelas' 
                        and hnp.aktif = true
                        and hnp.jenispelayananidfk = $jp                
                left join kelasmt as kls on kls.id = '$idkelas'                
                left join ruanganmt as ru on ru.id = so.ruangantujuanidfk
                left join instalasimt as dpm on dpm.id = ru.instalasiidfk
                left JOIN transaksipasientr as pps on pps.transaksiorderfk = so.norec
                      and op.produkidfk = pps.produkidfk
                where op.aktif = true AND op.koders = $kdProfile AND op.transaksiorderfk = :norec_so
                and kls.id=:objectkelasfk
                ORDER by op.tglpelayanan"),
            array(
                'norec_so' => $norec_so,
                'objectkelasfk' =>$idkelas ,
            )
        );

        $result=[];
        foreach ($dataOrderPelayanan as $item){
            $dataz =  DB::select(DB::raw("
                select hnp.komponenhargaidfk,kh.komponentarif,hnp.hargasatuan,
                hnp.produkidfk,hnp.jenispelayananidfk
                from tarifpelayanandmt as hnp   
                inner join pelayananmt as prd on prd.id=hnp.produkidfk
                inner join komponentarifmt as kh on kh.id=hnp.komponenhargaidfk
                inner join kelasmt as kls on kls.id = hnp.kelasidfk
                where hnp.koders = $kdProfile and hnp.kelasidfk = '$idkelas'
                and hnp.aktif=true
                and hnp.jenispelayananidfk=$jp
                and prd.id='$item->prid'"));

            $result[] = array(
                'norec_op' => $item->norec_op,
                'norec_pp' => $item->norec_pp,
                'prid' => $item->prid,
                'namaproduk' => $item->namaproduk,
                'qtyproduk' => $item->qtyproduk,
                'tglpelayanan' => $item->tglpelayanan,
                'idruangan' => $item->ruangantujuanidfk,
                'ruangantujuan' => $item->ruangantujuan,
                'hargasatuan' => $item->hargasatuan,
                'namakelas' => $item->namakelas,
                'objectdepartemenfk' => $item->instalasiidfk,
                'namadepartemen' => $item->namadepartemen,
                'details' => $dataz,
            );
        }

        $result=array(
            'message' =>  'ea',
            'data' =>  $result,
        );
        return $this->respond($result);
    }

    public function savePelayananPasien(Request $request) {
        $kdProfile = $this->getDataKdProfile($request);
        $idProfile = (int) $kdProfile;
        \DB::beginTransaction();
        try{
            StrukOrder::where('norec', $request['norec_so'])
                ->where('koders', $idProfile)
                ->update([
                        'statusorder' => 1
                    ]
                );

            $pd = PasienDaftar::where('norec',$request['norec_pd'])->where('koders', $idProfile)->first();
            $apd = AntrianPasienDiperiksa::where('registrasipasienfk',$pd->norec)
                ->where('koders', $idProfile)
                ->where('ruanganidfk',$request['ruangantujuanidfk'])
                ->where('aktif',true)
                ->first();
            if(empty($apd)){
                $dataAPD = new AntrianPasienDiperiksa;
                $dataAPD->norec = $dataAPD->generateNewId();
                $dataAPD->koders = $idProfile;
                $dataAPD->asalrujukanidfk = 1;
                $dataAPD->aktif = true;
                $dataAPD->kelasidfk = 6;// $request['objectkelasfk'];
                $dataAPD->noantrian = 1;
                $dataAPD->registrasipasienfk = $request['norec_pd'];
                $dataAPD->pegawaiidfk = $request['pegawaiorderidfk'];
                $dataAPD->ruanganidfk = $request['ruangantujuanidfk'];
                $dataAPD->ruanganasalidfk = $request['ruanganasalidfk'];
                $dataAPD->statusantrian = 0;
                $dataAPD->statuspasien = 1;
                $dataAPD->strukorderidfk = $request['norec_so'];
                $dataAPD->tglregistrasi = $pd->tglregistrasi;// date('Y-m-d H:i:s');
                $dataAPD->tglmasuk = date('Y-m-d H:i:s');
                $dataAPD->tglkeluar = date('Y-m-d H:i:s');
                $dataAPD->save();

                $dataAPDnorec = $dataAPD->norec;
                $dataAPDtglPel = $dataAPD->tglregistrasi;
            }else{
                $dataAPDnorec  = $apd->norec;
                $dataAPDtglPel = $apd->tglregistrasi;
            }

            $antrian = AntrianPasienDiperiksa::where('norec',$dataAPDnorec)
                ->update([
                    'ispelayananpasien' => true
                ]);

            foreach ($request['bridging'] as $item){
                $PelPasien = new PelayananPasien();
                $PelPasien->norec = $PelPasien->generateNewId();
                $PelPasien->koders = $idProfile;
                $PelPasien->aktif = true;
                $PelPasien->daftarpasienruanganfk =  $dataAPDnorec;
                $PelPasien->tglregistrasi = $dataAPDtglPel;
                $PelPasien->hargadiscount = 0;
                $PelPasien->hargajual =  $item['hargasatuan'];
                $PelPasien->hargasatuan =  $item['hargasatuan'];
                $PelPasien->jumlah =  $item['qtyproduk'];
                $PelPasien->kelasidfk =  $request['objectkelasfk'];
                $PelPasien->kdkelompoktransaksi =  1;
                $PelPasien->piutangpenjamin =  0;
                $PelPasien->piutangrumahsakit = 0;
                $PelPasien->produkidfk =  $item['produkid'];
                $PelPasien->stock =  1;
                $PelPasien->transaksiorderfk =  $request['norec_so'];
                $PelPasien->tglpelayanan = date('Y-m-d H:i:s');
                $PelPasien->harganetto =  $item['hargasatuan'];

                $PelPasien->save();
                $PPnorec = $PelPasien->norec;


                $PelPasienPetugas = new PelayananPasienPetugas();
                $PelPasienPetugas->norec = $PelPasienPetugas->generateNewId();
                $PelPasienPetugas->koders = $idProfile;
                $PelPasienPetugas->aktif = true;
                $PelPasienPetugas->nomasukidfk = $dataAPDnorec;
                $PelPasienPetugas->pegawaiidfk = $request['iddokterverif'];//$request['objectpegawaiorderfk'];
                $PelPasienPetugas->jenispetugaspeidfk = 4;//$jenisPetugasPe->objectjenispetugaspefk;
                $PelPasienPetugas->transaksipasienfk = $PPnorec;
                $PelPasienPetugas->save();
                $PPPnorec = $PelPasienPetugas->norec;


                foreach ($item['komponenharga'] as $itemKomponen) {

                    $PelPasienDetail = new PelayananPasienDetail();
                    $PelPasienDetail->norec = $PelPasienDetail->generateNewId();
                    $PelPasienDetail->koders = $idProfile;
                    $PelPasienDetail->aktif = true;
                    $PelPasienDetail->daftarpasienruanganfk = $dataAPDnorec;
                    $PelPasienDetail->aturanpakai = '-';
                    $PelPasienDetail->hargadiscount = 0;
                    $PelPasienDetail->hargajual = $itemKomponen['hargasatuan'];
                    $PelPasienDetail->hargasatuan = $itemKomponen['hargasatuan'];
                    $PelPasienDetail->jumlah = 1;
                    $PelPasienDetail->keteranganlain = '-';
                    $PelPasienDetail->keteranganpakai2 = '-';
                    $PelPasienDetail->komponenhargaidfk = $itemKomponen['komponenhargaidfk'];
                    $PelPasienDetail->transaksipasienfk = $PPnorec;
                    $PelPasienDetail->piutangpenjamin = 0;
                    $PelPasienDetail->piutangrumahsakit = 0;
                    $PelPasienDetail->produkidfk =  $item['produkid'];
                    $PelPasienDetail->stock = 1;
                    $PelPasienDetail->strukorderidfk =  $request['norec_so'];
                    $PelPasienDetail->tglpelayanan =$dataAPDtglPel;
                    $PelPasienDetail->harganetto = $itemKomponen['hargasatuan'];
                    $PelPasienDetail->save();
                    $PPDnorec = $PelPasienDetail->norec;
                    $transStatus = 'true';
                }
            }

            $transStatus = 'true';
        } catch (\Exception $e) {
            $transStatus = 'false';
        }

        if ($transStatus == 'true') {
            $transMessage = "Simpan Pelayanan Berhasil";
            DB::commit();
            $result = array(
                'status' => 201,
                'message' => $transMessage,
                'dataPP' => $PelPasien,
                'dataPPD' => $PelPasienDetail,
                'as' => 'ramdanegie',
            );
        } else {
            $transMessage = "Simpan Pelayanan Gagal";
            DB::rollBack();
            $result = array(
                'status' => 400,
                'message'  => $transMessage,
                'dataPP' => $PelPasien,
                'as' => 'ramdanegie',
            );
        }
        return $this->setStatusCode($result['status'])->respond($result, $transMessage);
    }

    public function getDetailVerifLabRad(Request $r){
        $kdProfile = (int) $this->getDataKdProfile($r);
        $data= \DB::select(DB::raw("select 
            pp.tglpelayanan,pp.jumlah,pp.hargasatuan,(pp.jumlah*pp.hargasatuan) as total,
            prd.namaproduk
            from transaksipasientr as pp
            join pelayananmt as prd on prd.id = pp.produkidfk
            where pp.transaksiorderfk = '$r[norec_so]'
            and pp.koders=$kdProfile and pp.aktif = true"));
        $res = array(
            "data" => $data,
            "as" => 'er@epic'
        );
        return $this->respond($res);
    }

    public function getDetailPasienPenunjang(Request $r){
        $kdProfile = (int) $this->getDataKdProfile($r);
        $data= \DB::select(DB::raw("
            select apd.registrasipasienfk AS norec_pd,apd.norec AS norec_apd
            from transaksipasientr as pp
            join daftarpasienruangantr as apd on apd.norec = pp.daftarpasienruanganfk
            where pp.transaksiorderfk = '$r[norec_so]'
            and pp.koders=$kdProfile and pp.aktif = true 
            and apd.aktif = true LIMIT 1"));
        $res = array(
            "data" => $data,
            "as" => 'er@epic'
        );
        return $this->respond($res);
    }

    public function getDaftarPasienPenunjang(Request $request) {
        $dataLogin = $request->all();
        $kdProfile = (int) $this->getDataKdProfile($request);
        $data = \DB::table('daftarpasienruangantr as apd')
            ->join('registrasipasientr as pd','pd.norec','=','apd.registrasipasienfk')
            ->JOIN('ruanganmt as ru','ru.id','=','apd.ruanganidfk')
            ->Join('instalasimt as dept', 'dept.id', '=', 'ru.instalasiidfk')
            ->JOIN ('pasienmt as ps','ps.id','=','pd.normidfk')
            ->JOIN('jeniskelaminmt as jk','jk.id','=','ps.jeniskelaminidfk')
            ->leftJoin('kelompokpasienmt as kp','kp.id','=','pd.kelompokpasienlastidfk')
            ->leftJoin('rekananmt as rk','rk.id','=','pd.rekananidfk')
            ->leftJoin('kelasmt as kl','kl.id','=','pd.kelasidfk')
            ->leftJoin('strukpelayanantr as sp','sp.norec','=','pd.nostruklastidfk')
            ->leftJoin('alamatmt as alm','alm.normidfk','=','ps.id')
            ->leftJoin('golongandarahmt as gol','gol.id','=','ps.golongandarahidfk')
            ->leftjoin('transaksiordertr as so','so.norec','=','apd.strukorderidfk')
            ->leftJoin('ruanganmt as ru1','ru1.id','=','so.ruanganidfk')
            ->select(DB::raw("
                apd.norec AS norec_apd,ru.id AS ruid,ru.namaruangan,pd.noregistrasi,
			    ps.norm,ps.namapasien,jk.jeniskelamin,kp.kelompokpasien,rk.namarekanan,
			    kl.namakelas,kl.id AS klid,pd.tglregistrasi,pd.tglpulang,ps.tgllahir,
			    apd.norec,pd.norec AS norec_pd,sp.tglstruk,pd.nostruklastidfk,
			    alm.alamatlengkap,gol.golongandarah,apd.tglmasuk,ru1.namaruangan AS ruanganasal,
			    '' AS expertise
            "))
            ->where('apd.koders', $kdProfile)
            ->where('apd.aktif', true)
            ->where('ru.kelompokuseridfk',$request['KelUserid'])
            ->orderBy('apd.tglmasuk','desc');

        if(isset($request['tglAwal']) && $request['tglAwal']!="" && $request['tglAwal']!="undefined"){
            $data = $data->where('apd.tglmasuk','>=', $request['tglAwal']);
        }
        if(isset($request['tglAkhir']) && $request['tglAkhir']!="" && $request['tglAkhir']!="undefined"){
            $data = $data->where('apd.tglmasuk','<=', $request['tglAkhir']);
        }
        if(isset($request['deptId']) && $request['deptId']!="" && $request['deptId']!="undefined"){
            $data = $data->where('dept.id','=', $request['deptId']);
        }
        if(isset($request['ruangId']) && $request['ruangId']!="" && $request['ruangId']!="undefined"){
            $data = $data->where('ru.id','=', $request['ruangId']);
        }
        if(isset($request['kelId']) && $request['kelId']!="" && $request['kelId']!="undefined"){
            $data = $data->where('kp.id','=', $request['kelId']);
        }
        if(isset($request['noregistrasi']) && $request['noregistrasi']!="" && $request['noregistrasi']!="undefined"){
            $data = $data->where('pd.noregistrasi','ilike','%'. $request['noregistrasi'].'%');
        }
        if(isset($request['nocm']) && $request['nocm']!="" && $request['nocm']!="undefined"){
            $data = $data->where('ps.norm','ilike','%'. $request['nocm'].'%');
        }
        if(isset($request['namapasien']) && $request['namapasien']!="" && $request['namapasien']!="undefined"){
            $data = $data->where('ps.namapasien','ilike','%'. $request['namapasien'].'%');
        }
        if(isset($request['jmlRow']) && $request['jmlRow']!="" && $request['jmlRow']!="undefined"){
            $data = $data->take($request['jmlRow']);
        }
        $data = $data->get();
        $apdnorec= [];
        foreach ($data as $key => $v) {
            $norecapd = $v->norec_apd;
            $apdnorec [] = $v->norec_apd;
        }
        $hasilRad = DB::table('transaksipasientr as pp')
            ->join('hasilradiologitr as hh','pp.norec','=','hh.transaksipasienfk')
            ->distinct()
            ->select('hh.tanggal', 'pp.daftarpasienruanganfk as norec_apd')
            ->whereIn('pp.daftarpasienruanganfk',$apdnorec)
            ->orderBy('hh.tanggal','desc')
            ->get();
        $hasilLab = DB::table('transaksipasientr as pp')
            ->join('hasillaboratoriumkliniktr as hh','pp.norec','=','hh.transaksipasienfk')
            ->distinct()
            ->select('hh.tglhasil as tanggal', 'pp.daftarpasienruanganfk as norec_apd')
            ->whereIn('pp.daftarpasienruanganfk',$apdnorec)
            ->orderBy('hh.tglhasil','desc')
            ->get();
        $hasilLabPA = DB::table('transaksipasientr as pp')
            ->join('hasillaboratoriumpatologitr as hh','pp.norec','=','hh.transaksipasienfk')
            ->distinct()
            ->select('hh.tanggal', 'pp.daftarpasienruanganfk as norec_apd')
            ->whereIn('pp.daftarpasienruanganfk',$apdnorec)
            ->orderBy('hh.tanggal','desc')
            ->get();

//        if ($hasilRad != null || $hasilLab != null || $hasilLabPA != null){
//            $dataMerge =  array_merge($hasilRad,$hasilLab,$hasilLabPA);
//            //return $dataMerge;
//            $i=0;
//            foreach ($data as $key => $v) {
//                $data[$i]->expertise = false;
//                $data[$i]->tglexpertise =null;
//                foreach ($dataMerge as $key2 => $v2) {
//                    if($data[$i]->norec_apd ==  $v2->norec_apd){
//                        $data[$i]->expertise =true;
//                        $data[$i]->tglexpertise =$v2->tanggal;
//                    }
//                }
//                $i = $i + 1;
//            }
//        }

        $result = array(
            "data" => $data,
//            "ruanganlogin" => $dataruangan,
            "as" => 'er@epic',
        );
        return $this->respond($result);
    }

    public function updateGolonganDarah(Request $request){
        $kdProfile = $this->getDataKdProfile($request);
        $idProfile = (int) $kdProfile;
        try {

        $dataApr = Pasien::where('norm', $request['norm'])
            ->where('koders', $idProfile)
            ->update([
                'golongandarahidfk' => $request['golongandarahidfk'],
            ]);

            $transStatus = 'true';
        }catch (\Exception $e) {
            $transStatus = 'false';
        }
        if ($transStatus == 'true') {
            $transMessage = "Update Berhasil";
            \DB::commit();
            $result = array(
                "status" => 201,
                "message" => $transMessage,
            );
        } else {
            $transMessage = "Update Gagal";
            DB::rollBack();
            $result = array(
                "status" => 400,
                "message"  => $transMessage,
            );
        }
        return $this->setStatusCode($result['status'])->respond($result, $transMessage);
    }

    public function getRincianPelayanan(Request $request) {
        $idProfile = (int) $this->getDataKdProfile($request);
        $pelayanan=[];
        $result = [];

        if ($request['KelUser'] == "laboratorium") {
            $pelayanan = \DB::table('transaksipasientr as pp')
                ->JOIN('daftarpasienruangantr as apd', 'apd.norec', '=', 'pp.daftarpasienruanganfk')
                ->JOIN('registrasipasientr as pd', 'pd.norec', '=', 'apd.registrasipasienfk')
                ->JOIN('pasienmt as ps', 'ps.id', '=', 'pd.normidfk')
                ->leftJOIN('jeniskelaminmt as jk', 'jk.id', '=', 'ps.jeniskelaminidfk')
                ->JOIN('pelayananmt as pr', 'pr.id', '=', 'pp.produkidfk')
                ->JOIN('ruanganmt as ru', 'ru.id', '=', 'apd.ruanganidfk')
                ->JOIN('instalasimt as dp', 'dp.id', '=', 'ru.instalasiidfk')
                ->leftJOIN('strukpelayanantr as sp', 'sp.norec', '=', 'pp.strukfk')
                ->leftjoin('strukbuktipenerimaantr as sbm', 'sp.nosbmlastidfk', '=', 'sbm.norec')
                ->leftJOIN('transaksiordertr as so', 'so.norec', '=', 'pp.transaksiorderfk')
                ->leftjoin('pmimt as pmi','pmi.id','=','pp.pmiidfk')
                ->leftJOIN('order_lab as lis', 'lis.no_lab', '=',
                    DB::raw("so.noorder AND 
                        lis.kode_test =cast (pr.id as VARCHAR)   "))
                ->select(DB::raw("
                     ps.norm,ps.namapasien,jk.jeniskelamin,pp.tglpelayanan,pp.produkidfk,pr.namaproduk,
                     pp.jumlah,pp.hargasatuan,pp.hargadiscount,sp.nostruk,pd.noregistrasi,ru.namaruangan,
                     dp.namadepartemen,ps.id AS psid,apd.norec AS norec_apd,sp.norec AS norec_sp,
                     pp.norec AS norec_pp,ru.instalasiidfk,so.noorder,lis.no_lab AS idbridging,
                     so.keteranganlainnya,apd.ruanganidfk,pp.iscito,pp.jasa,ps.jeniskelaminidfk,
                     ps.tgllahir,sbm.nosbm,pmi.pmi,so.keteranganlainnya,
                     CASE WHEN lis.no_lab IS NOT NULL THEN 'Sudah Dikirim' ELSE '-' END AS statusbridging,
                     '' AS hr_norec,NULL AS nourutrad
                "))
                ->where('pp.aktif', true)
                ->where('pp.koders',$idProfile)
                ->where('ru.instalasiidfk', $this->settingDataFixed('kdDepartemenLab', $idProfile))
                ->orderBy('pp.tglpelayanan');
        }
        if ($request['KelUser'] == "radiologi") {
            $pelayanan = \DB::table('transaksipasientr as pp')
                ->JOIN('daftarpasienruangantr as apd', 'apd.norec', '=', 'pp.daftarpasienruanganfk')
                ->JOIN('registrasipasientr as pd', 'pd.norec', '=', 'apd.registrasipasienfk')
                ->JOIN('pasienmt as ps', 'ps.id', '=', 'pd.normidfk')
                ->leftJOIN('jeniskelaminmt as jk', 'jk.id', '=', 'ps.jeniskelaminidfk')
                ->JOIN('pelayananmt as pr', 'pr.id', '=', 'pp.produkidfk')
                ->JOIN('ruanganmt as ru', 'ru.id', '=', 'apd.ruanganidfk')
                ->JOIN('instalasimt as dp', 'dp.id', '=', 'ru.instalasiidfk')
                ->leftJOIN('strukpelayanantr as sp', 'sp.norec', '=', 'pp.strukfk')
                ->leftjoin('strukbuktipenerimaantr as sbm', 'sp.nosbmlastidfk', '=', 'sbm.norec')
                ->leftJOIN('transaksiordertr as so', 'so.norec', '=', 'pp.transaksiorderfk')
                ->leftjoin('pmimt as pmi','pmi.id','=','pp.pmiidfk')
                ->leftJOIN('ris_order as ris', 'ris.order_no', '=',
                    \DB::raw('so.noorder AND ris.order_code=cast(pp.produkidfk as text)'))
                ->leftJOIN('hasilradiologitr AS hr','hr.transaksipasienfk','=',
                    DB::raw("pp.norec AND hr.aktif = true "))
                ->select(DB::raw("
                     ps.norm,ps.namapasien,jk.jeniskelamin,pp.tglpelayanan,pp.produkidfk,pr.namaproduk,
                     pp.jumlah,pp.hargasatuan,pp.hargadiscount,sp.nostruk,pd.noregistrasi,ru.namaruangan,
                     dp.namadepartemen,ps.id AS psid,apd.norec AS norec_apd,sp.norec AS norec_sp,
                     pp.norec AS norec_pp,ru.instalasiidfk,so.noorder,ris.order_key AS idbridging,
                     apd.ruanganidfk,pp.iscito,pp.jasa,so.keteranganlainnya,ps.jeniskelaminidfk,
                     ps.tgllahir,sbm.nosbm,pmi.pmi,ris.order_cnt AS nourutrad,
                     CASE WHEN ris.order_key IS NOT NULL THEN 'Sudah Dikirim' ELSE '-' END AS statusbridging,
		             hr.norec AS hr_norec
                "))
                ->where('pp.aktif', true)
                ->where('pp.koders',$idProfile)
                ->where('ru.instalasiidfk', $this->settingDataFixed('kdDepartemenRad', $idProfile))
                ->groupBy(DB::raw("
                     ps.norm,ps.namapasien,jk.jeniskelamin,pp.tglpelayanan,pp.produkidfk,pr.namaproduk,
                     pp.jumlah,pp.hargasatuan,pp.hargadiscount,sp.nostruk,pd.noregistrasi,ru.namaruangan,
                     dp.namadepartemen,ps.id,apd.norec,sp.norec,pp.norec,ru.instalasiidfk,so.noorder,
                     ris.order_key,apd.ruanganidfk,pp.iscito,pp.jasa,hr.norec,sbm.nosbm,pmi.pmi,
                     so.keteranganlainnya
                "))
                ->orderBy('pp.tglpelayanan');
        }
        if ($request['KelUser'] == "bedah") {
            $pelayanan = \DB::table('transaksipasientr as pp')
                ->JOIN('daftarpasienruangantr as apd', 'apd.norec', '=', 'pp.daftarpasienruanganfk')
                ->JOIN('registrasipasientr as pd', 'pd.norec', '=', 'apd.registrasipasienfk')
                ->JOIN('pasienmt as ps', 'ps.id', '=', 'pd.normidfk')
                ->leftJOIN('jeniskelaminmt as jk', 'jk.id', '=', 'ps.jeniskelaminidfk')
                ->JOIN('pelayananmt as pr', 'pr.id', '=', 'pp.produkidfk')
                ->JOIN('ruanganmt as ru', 'ru.id', '=', 'apd.ruanganidfk')
                ->JOIN('instalasimt as dp', 'dp.id', '=', 'ru.instalasiidfk')
                ->leftJOIN('strukpelayanantr as sp', 'sp.norec', '=', 'pp.strukfk')
                ->leftjoin('strukbuktipenerimaantr as sbm', 'sp.nosbmlastidfk', '=', 'sbm.norec')
                ->leftJOIN('transaksiordertr as so', 'so.norec', '=', 'pp.transaksiorderfk')
                ->leftjoin('pmimt as pmi','pmi.id','=','pp.pmiidfk')
                ->select(DB::raw("
                     ps.norm,ps.namapasien,jk.jeniskelamin,pp.tglpelayanan,pp.produkidfk,pr.namaproduk,
                     pp.jumlah,pp.hargasatuan,pp.hargadiscount,sp.nostruk,pd.noregistrasi,ru.namaruangan,
                     dp.namadepartemen,ps.id AS psid,apd.norec AS norec_apd,sp.norec AS norec_sp,
                     pp.norec AS norec_pp,ru.instalasiidfk,so.noorder,null AS idbridging,
                     so.keteranganlainnya,apd.ruanganidfk,pp.iscito,pp.jasa,ps.jeniskelaminidfk,
                     ps.tgllahir,sbm.nosbm,pmi.pmi,so.keteranganlainnya,
                     '-' AS statusbridging,
                     '' AS hr_norec,NULL AS nourutrad
                "))
                ->where('pp.aktif', true)
                ->where('pp.koders',$idProfile)
                ->where('ru.instalasiidfk', $this->settingDataFixed('kdDepartemenOK', $idProfile))
                ->orderBy('pp.tglpelayanan');
        }
//        if ($request['KelUser'] == "elektromedik") {
//            $pelayanan = \DB::table('pelayananpasien_t as pp')
//                ->JOIN('antrianpasiendiperiksa_t as apd', 'apd.norec', '=', 'pp.noregistrasifk')
//                ->JOIN('pasiendaftar_t as pd', 'pd.norec', '=', 'apd.noregistrasifk')
//                ->JOIN('pasien_m as ps', 'ps.id', '=', 'pd.nocmfk')
//                ->leftJOIN('jeniskelamin_m as jk', 'jk.id', '=', 'ps.objectjeniskelaminfk')
//                ->JOIN('produk_m as pr', 'pr.id', '=', 'pp.produkfk')
//                ->JOIN('ruangan_m as ru', 'ru.id', '=', 'apd.objectruanganfk')
//                ->JOIN('departemen_m as dp', 'dp.id', '=', 'ru.objectdepartemenfk')
//                ->leftJOIN('strukpelayanan_t as sp', 'sp.norec', '=', 'pp.strukfk')
//                ->leftjoin('pmi_m as pmi','pmi.id','=','pp.pmifk')
//                ->leftjoin('strukbuktipenerimaan_t as sbm', 'sp.nosbmlastfk', '=', 'sbm.norec')
//                ->leftJOIN('strukorder_t as so', 'so.norec', '=', 'pp.strukorderfk')
////                    ->leftJOIN('orderpelayanan_t op', 'so.norec', '=', 'op.strukorderfk') // syamsu tambahan
////                    ->leftJOIN('lisorder as lis', 'lis.ono', '=', 'so.noorder')
//                ->select('ps.nocm', 'ps.namapasien', 'jk.jeniskelamin', 'pp.tglpelayanan', 'pp.produkfk', 'pr.namaproduk',
//                    'pp.jumlah', 'pp.hargasatuan', 'pp.hargadiscount', 'sp.nostruk', 'pd.noregistrasi', 'ru.namaruangan',
//                    'dp.namadepartemen', 'ps.id as psid', 'apd.norec as norec_apd', 'sp.norec as norec_sp', 'pp.norec as norec_pp',
//                    'ru.objectdepartemenfk', 'so.noorder', 'apd.objectruanganfk','pp.iscito','pp.jasa','ps.objectjeniskelaminfk','ps.tgllahir','so.keteranganlainnya',
//                    'sbm.nosbm','pmi.pmi',
//                    DB::raw("'-' as statusbridging, null as idbridging,'' as hr_norec , '' as nourutrad")) // syamsu tambahan
//                ->where('pp.kdprofile',$idProfile)
//                ->where('ru.objectdepartemenfk', $this->settingDataFixed('kdDepartemenElektromedik', $idProfile))
//                ->orderBy('pp.tglpelayanan');
//        }
            if (isset($request['departemenfk']) && $request['departemenfk'] != "" && $request['departemenfk'] != "undefined") {
                $pelayanan = $pelayanan->where('ru.instalasiidfk', '=', $request['departemenfk']);
            }
            if (isset($request['nocm']) && $request['nocm'] != "" && $request['nocm'] != "undefined") {
                $pelayanan = $pelayanan->where('ps.norm', '=', $request['nocm']);
            }
            if (isset($request['norec_apd']) && $request['norec_apd'] != "" && $request['norec_apd'] != "undefined") {
                $pelayanan = $pelayanan->where('pp.daftarpasienruanganfk', '=', $request['norec_apd']);
            }
            if (isset($request['noregistrasi']) && $request['noregistrasi'] != "" && $request['noregistrasi'] != "undefined") {
                $pelayanan = $pelayanan->where('pd.noregistrasi', '=', $request['noregistrasi']);
            }
            $pelayanan = $pelayanan->get();
            if (count($pelayanan) > 0) {
                $pelayananpetugas = \DB::table('registrasipasientr as pd')
                    ->join('daftarpasienruangantr as apd', 'apd.registrasipasienfk', '=', 'pd.norec')
                    ->join('petugaspelaksanatr as ptu', 'ptu.nomasukidfk', '=', 'apd.norec')
                    ->leftjoin('pegawaimt as pg', 'pg.id', '=', 'ptu.pegawaiidfk')
                    ->select('ptu.transaksipasienfk', 'pg.namalengkap', 'pg.id')
                    ->where('pd.koders',$idProfile)
                    ->where('ptu.aktif', true)
                    ->where('ptu.jenispetugaspeidfk', 4)
                    ->where('pd.noregistrasi', $pelayanan[0]->noregistrasi)
                    ->get();

                $result = [];
                foreach ($pelayanan as $item) {
                    if (isset($request['noregistrasifk'])) {
                        $diskon = $item->hargadiscount;
                    } else {
                        $diskon = 0;
                    }
                    $NamaDokter = '-';
                    $DokterId = '';
                    foreach ($pelayananpetugas as $hahaha) {
                        if ($hahaha->transaksipasienfk == $item->norec_pp) {
                            $NamaDokter = $hahaha->namalengkap;
                            $DokterId = $hahaha->id;
                        }
                    }
                    $total = (((float)$item->hargasatuan - (float)$diskon) * (float)$item->jumlah ) + (float)$item->jasa ;
                    $result[] = array(
                        'norm' => $item->norm,
                        'namapasien' => $item->namapasien,
                        'jeniskelamin' => $item->jeniskelamin,
                        'tglpelayanan' => $item->tglpelayanan,
                        'produkfk' => $item->produkidfk,
                        'namaproduk' => $item->namaproduk,
                        'jumlah' => (float)$item->jumlah,
                        'hargasatuan' => (float)$item->hargasatuan,
                        'hargadiscount' => (float)$diskon,
                        'total' => (float)$total,
                        'nostruk' => $item->nostruk,
                        'noregistrasi' => $item->noregistrasi,
                        'ruangan' => $item->namaruangan,
                        'objectruanganfk' => $item->ruanganidfk,
                        'departemen' => $item->namadepartemen,
                        'objectdepartemenfk' => $item->instalasiidfk,
                        'norec_apd' => $item->norec_apd,
                        'norec_sp' => $item->norec_sp,
                        'norec_pp' => $item->norec_pp,
                        'nourutrad' => $item->nourutrad,
                        'idpatient' => ($item->nourutrad == null) ? '-' : $item->nocm. '-'.$item->nourutrad,
                        'dokter' => $NamaDokter,
                        'dokterid' => $DokterId,
                        'noorder' => $item->noorder,
                        'idbridging' => $item->idbridging,
                        'statusbridging' => $item->statusbridging,
                        'iscito' => $item->iscito,
                        'jasa' => (float)$item->jasa,
                        'objectjeniskelaminfk' => $item->jeniskelaminidfk,
                        'tgllahir' => $item->tgllahir,
                        'nosbm' => $item->nosbm,
                        'hr_norec' => $item->hr_norec,
                        'pmi' => $item->pmi,
                        'keteranganlainnya' => $item->keteranganlainnya
                    );
                }
            }
        $dataTea =array(
            'data' => $result,
            'message' => 'Inhuman'
        );
        return $this->respond($dataTea);
    }

    public function getDataRuanganAntrian(Request $request){
        $idProfile = (int) $this->getDataKdProfile($request);
        $data = \DB::table('daftarpasienruangantr as apd')
            ->join('registrasipasientr as pd', 'pd.norec', '=', 'apd.registrasipasienfk')
            ->join('ruanganmt as ru', 'ru.id', '=', 'apd.ruanganidfk')
            ->join('pasienmt as ps', 'ps.id', '=', 'pd.normidfk')
            ->join('kelasmt as kls', 'kls.id', '=', 'apd.kelasidfk')
            ->select(DB::raw("
                apd.ruanganidfk AS id,ru.namaruangan,apd.norec AS norec_apd
            "))
            ->where('apd.aktif', true)
            ->where('pd.aktif', true)
            ->where('apd.koders', $idProfile)
            ->where('pd.noregistrasi', $request['noregistrasi'])
            ->orderBy('pd.ruanganlastidfk')
            ->get();

        $result = array(
            'ruangan' => $data,
            'message' => 'er@epic',
        );
        return $this->respond($result);
    }

    public function saveAntrianPasienPenunjang(Request $request){
        $idProfile = (int) $this->getDataKdProfile($request);
        \DB::beginTransaction();

        try {
            $countNoAntrian = AntrianPasienDiperiksa::where('ruanganidfk',$request['objectruanganasalfk'])
                ->where('aktif', true)
                ->where('koders', $idProfile)
                ->where('tglregistrasi', '>=', $request['tglregistrasidate'].' 00:00')
                ->where('tglregistrasi', '<=', $request['tglregistrasidate'].' 23:59')
                ->count('norec');
            $pd = PasienDaftar::where('norec',$request['norec_pd'])->first();
            $noAntrian = $countNoAntrian + 1;
            $dataAPD = new AntrianPasienDiperiksa;
            $dataAPD->norec = $dataAPD->generateNewId();
            $dataAPD->koders = $idProfile;
            $dataAPD->aktif = true;
            $dataAPD->asalrujukanidfk = $request['asalrujukanfk'];
            $dataAPD->kelasidfk = $request['objectkelasfk'];
            $dataAPD->noantrian = $noAntrian;
            $dataAPD->registrasipasienfk = $request['norec_pd'];
            $dataAPD->pegawaiidfk = $request['dokterfk'];
            $dataAPD->ruanganidfk = $request['objectruangantujuanfk'];
            $dataAPD->statusantrian = 0;
            $dataAPD->statuspasien = 1;
            $dataAPD->statuskunjungan = 'LAMA';
            $dataAPD->statuspenyakit = 'BARU';
            $dataAPD->ruanganasalidfk = $request['objectruanganasalfk'];;
            $dataAPD->tglregistrasi = $pd->tglregistrasi;//date('Y-m-d H:i:s');
            $dataAPD->tglkeluar = date('Y-m-d H:i:s');
            $dataAPD->tglmasuk = date('Y-m-d H:i:s');
            $dataAPD->save();

            $dataAPDnorec = $dataAPD->norec;
            $transStatus = 'true';
            $transMessage = "Simpan Antrian Berhasil";
        } catch (\Exception $e) {
            $transStatus = 'false';
            $transMessage = "Simpan Antrian Gagal";
        }

        if ($transStatus != 'false') {
            DB::commit();
            $result = array(
                "status" => 201,
                "data" => $dataAPD,
                "message" => $transMessage,
            );
        } else {
            DB::rollBack();
            $result = array(
                "status" => 400,
                "message" => $transMessage,
            );
        }

        return $this->setStatusCode($result['status'])->respond($result, $transMessage);
    }

    public function getHasilRadiologi(Request $request) {
        $kdProfile =(int) $this->getDataKdProfile($request);
        $data = \DB::table('hasilradiologitr as ar')
            ->leftjoin('pegawaimt as pg', 'pg.id', '=', 'ar.pegawaiidfk')
            ->select(DB::raw("
                ar.*, pg.namalengkap
            "))
            ->where('ar.koders', $kdProfile)
            ->where('ar.aktif',true)
            ->where('ar.transaksipasienfk',$request['norec_pp'])
            ->get();
        return $this->respond($data);
    }

    public function saveHasilRadiologi(Request $request) {
        $idProfile = (int) $this->getDataKdProfile($request);
        \DB::beginTransaction();
        try{

            if ($request['norec']=="") {
                $dataSO = new HasilRadiologi();
                $dataSO->norec = $dataSO->generateNewId();
                $dataSO->koders = $idProfile;
                $dataSO->aktif = true;
            }else {
                $dataSO =  HasilRadiologi::where('norec',$request['norec'])->first();
            }
            $dataSO->tanggal =$request['tglinput'];
            $dataSO->pegawaiidfk = $request['dokterid'];
            if(isset( $request['nofoto'])){
                $dataSO->nofoto = $request['nofoto'];
            }
            $dataSO->keterangan = $request['keterangan'];
            $dataSO->transaksipasienfk = $request['pelayananpasienfk'];
            $dataSO->registrasipasienfk = $request['norec_pd'];
            $dataSO->save();

            $transStatus = 'true';
        } catch (\Exception $e) {
            $transStatus = 'false';

        }

        if ($transStatus == 'true') {

            $transMessage = "Simpan";
            DB::commit();
            $result = array(
                "status" => 201,
                "message" => $transMessage,
                "strukorder" => $dataSO,
                "as" => 'inhuman',
            );

        } else {
            $transMessage = "Simpan  gagal!!";
            DB::rollBack();
            $result = array(
                "status" => 400,
                "message"  => $transMessage,
                "as" => 'inhuman',
            );
        }
        return $this->setStatusCode($result['status'])->respond($result, $transMessage);
    }

    public function getHasilLabPA(Request $request) {
        $kdProfile = (int) $this->getDataKdProfile($request);
        $data = \DB::table('hasillaboratoriumpatologitr as ar')
            ->leftjoin('pegawaimt as pg', 'pg.id', '=', 'ar.pegawaiidfk')
            ->leftjoin('pegawaimt as dokterpengirim', 'dokterpengirim.id', '=', 'ar.dokterpengirimidfk')
            ->select('ar.*','pg.namalengkap','dokterpengirim.namalengkap as namadokterpengirim')
            ->where('ar.koders', $kdProfile)
            ->where('ar.aktif',true)
            ->where('ar.transaksipasienfk',$request['norec_pp'])
            ->get();
        return $this->respond($data);
    }

    public function saveHasilLabPA(Request $request) {
        $idProfile = (int) $this->getDataKdProfile($request);
        \DB::beginTransaction();
        try{
            if ($request['norec']=="") {
                $dataSO = new HasilPemeriksaanLab();
                $dataSO->norec = $dataSO->generateNewId();
                $dataSO->koders = $idProfile;
                $dataSO->aktif = true;
            }else {
                $dataSO =  HasilPemeriksaanLab::where('norec',$request['norec'])->first();
            }
            if ($request['isDokterLuar'] == true) {
                $dataSO->dokterluar = $request['dokterpengirim2'];
                $dataSO->dokterpengirimidfk = NULL;
            }
            else {
                $dataSO->dokterluar = NULL;
                $dataSO->dokterpengirimidfk = $request['dokterpengirim1'];
            }
            $dataSO->nomorpa = $request['nomor'];
            $dataSO->tanggal =$request['tglinput'];
            $dataSO->pegawaiidfk = $request['dokterid'];
            $dataSO->jenis = $request['jenis'];
            $dataSO->transaksipasienfk = $request['pelayananpasienfk'];
            $dataSO->registrasipasienfk = $request['norec_pd'];
            $dataSO->diagnosaklinik = $request['diagnosaklinik'];
            $dataSO->keteranganklinik = $request['keteranganklinik'];
            $dataSO->diagnosapb = $request['diagnosapb'];
            $dataSO->keteranganpb = $request['keteranganpb'];
            $dataSO->topografi = $request['topografi'];
            $dataSO->morfologi = $request['morfologi'];
            $dataSO->makroskopik = $request['makroskopik'];
            $dataSO->mikroskopik = $request['mikroskopik'];
            $dataSO->kesimpulan = $request['kesimpulan'];
            $dataSO->anjuran = $request['anjuran'];
            $dataSO->jaringanasal = $request['jaringanasal'];
            $dataSO->save();

            $transStatus = 'true';
        } catch (\Exception $e) {
            $transStatus = 'false';
        }

        if ($transStatus == 'true') {

            $transMessage = "Simpan Berhasil";
            DB::commit();
            $result = array(
                "status" => 201,
                "message" => $transMessage,
                "dataSave" => $dataSO,
                "as" => 'inhuman',
            );

        } else {
            $transMessage = "Simpan  Gagal!!";
            DB::rollBack();
            $result = array(
                "status" => 400,
                "message"  => $transMessage,
                "as" => 'inhuman',
            );
        }
        return $this->setStatusCode($result['status'])->respond($result, $transMessage);
    }
}
