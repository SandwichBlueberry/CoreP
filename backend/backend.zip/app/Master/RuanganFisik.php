<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class RuanganFisik extends MasterModel
{
    protected $table ="jenispegawai_m";
    protected $fillable = [];


}
