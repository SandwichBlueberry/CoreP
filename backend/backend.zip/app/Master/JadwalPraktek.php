<?php
/**
 * Created by PhpStorm.
 * User: JASAMEDIKA
 * Date: 18/07/2018
 * Time: 16:02
 */

namespace App\Master;


class JadwalPraktek  extends MasterModel
{
    protected $table = 'jadwalpraktek_m';
    protected $fillable = [];
    public $timestamps = false;


}