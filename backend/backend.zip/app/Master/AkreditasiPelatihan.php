<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 17/12/2018
 * Time: 11.21
 */

namespace App\Master;

class AkreditasiPelatihan extends MasterModel
{
    protected $table = 'akreditasipelatihan_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = 'id';

}
