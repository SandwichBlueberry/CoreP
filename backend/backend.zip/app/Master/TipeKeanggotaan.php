<?php
/**
 * Created by PhpStorm.
 * User: Jasamedika
 * Date: 30/07/2018
 * Time: 14.32
 */

namespace App\Master;

class TipeKeanggotaan extends MasterModel
{
    protected $table ="sdm_tipekeanggotaan_m";
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = "id";


}
