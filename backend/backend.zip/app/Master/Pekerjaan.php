<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/29/2019
 * Time: 3:45 PM
 */

namespace App\Master;


class Pekerjaan  extends MasterModel
{
    protected $table ="pekerjaan_m";
    protected $fillable = [];
    public $timestamps = false;
}