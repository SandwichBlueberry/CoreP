<?php

namespace App\Master;

class KelompokAnggaranPertama extends MasterModel
{
    protected $table = 'kelompokanggaranpertama_m';
    protected $fillable = [];
    public $timestamps = false;


}


