<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class MasterRL1Sub3 extends MasterModel
{
    protected $table ="masterrl_1_3_m";
    protected $fillable = [];

    public $timestamps = false;
    protected $primaryKey = "id";


}
