<?php

namespace App\Master;

class KelompokAnggaranKeempat extends MasterModel
{
    protected $table = 'kelompokanggarankeempat_m';
    protected $fillable = [];
    public $timestamps = false;


}


