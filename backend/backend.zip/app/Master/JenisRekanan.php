<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class JenisRekanan extends MasterModel
{
    protected $table ="jenisrekanan_m";
    protected $fillable = [];
}
