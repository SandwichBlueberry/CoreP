<?php
/**
 * Created by PhpStorm.
 * User: GIW
 * Date: 9/30/2019
 * Time: 9:26 AM
 */

namespace App\Master;

class SiklusGizi extends MasterModel
{
    protected $table = "siklusgizi_m";
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = "id";


}