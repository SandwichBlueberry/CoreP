<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/29/2019
 * Time: 3:43 PM
 */

namespace App\Master;


class HubunganKeluarga extends MasterModel
{
    protected $table = "hubungankeluarga_m";
    protected $fillable = [];
    public $timestamps = false;
}