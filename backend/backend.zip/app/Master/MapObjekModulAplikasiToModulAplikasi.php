<?php
/**
 * Created by IntelliJ IDEA.
 * User: Egie Ramdan
 * Date: 12/02/2019
 * Time: 13.45
 */
namespace App\Master;

class MapObjekModulAplikasiToModulAplikasi extends MasterModel
{
	protected $table ="mapobjekmodulaplikasitomodulaplikasi_s";
	protected $fillable = [];
	public $timestamps = false;
}

