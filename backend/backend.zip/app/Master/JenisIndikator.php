<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 19/12/2018
 * Time: 10.06
 */
namespace App\Master;

class JenisIndikator extends MasterModel
{
    protected $table = 'jenisindikator_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = 'id';

}
