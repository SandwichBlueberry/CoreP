<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 18/12/2018
 * Time: 15.50
 */
namespace App\Master;

class TargetIndikator extends MasterModel
{
    protected $table = 'targetindikator_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = 'id';

}
