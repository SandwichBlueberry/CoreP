<?php

namespace App\Master;

class KelompokAnggaranKeenam extends MasterModel
{
    protected $table = 'kelompokanggarankeenam_m';
    protected $fillable = [];
    public $timestamps = false;


}


