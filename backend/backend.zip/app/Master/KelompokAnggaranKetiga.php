<?php

namespace App\Master;

class KelompokAnggaranKetiga extends MasterModel
{
    protected $table = 'kelompokanggaranketiga_m';
    protected $fillable = [];
    public $timestamps = false;


}


