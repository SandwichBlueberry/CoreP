<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/23/2019
 * Time: 4:13 PM
 */

namespace App\Master;


class GolonganPegawai extends MasterModel
{
    protected $table ="sdm_golongan_m";
    protected $fillable = [];
    public $timestamps = false;
}