<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 11/12/2018
 * Time: 16.38
 */

namespace App\Master;

class JenisPelatihan extends MasterModel
{
    protected $table = 'jenispelatihan_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = 'id';

}
