<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;
//use DB;

class UnitKerjaPegawai extends MasterModel
{
    protected $table = 'unitkerjapegawai_m';
    protected $fillable = [];
    public $timestamps = false;


}


