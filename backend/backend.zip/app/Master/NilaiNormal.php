<?php

namespace App\Master;



class NilaiNormal extends MasterModel
{
    protected $table = 'nilainormal_m';
    protected $fillable = [];
    public $timestamps = false;

}


