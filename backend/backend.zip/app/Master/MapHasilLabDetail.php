<?php

namespace App\Master;

class MapHasilLabDetail extends MasterModel
{
    protected $table = 'maphasillabdetail_m';
    protected $fillable = [];
    public $timestamps = false;

}

