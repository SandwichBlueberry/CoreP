<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class JenisPetugasPelaksana extends MasterModel
{
    protected $table ="jenispetugaspelaksana_m";
    protected $fillable = [];


}
