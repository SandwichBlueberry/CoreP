<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 17/12/2018
 * Time: 11.29
 */
namespace App\Master;

class SDM_Golongan extends MasterModel
{
    protected $table = 'sdm_golongan_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = 'id';

}
