<?php

namespace App\Master;


class MapLoginUsertoRuangan extends MasterModel
{
    protected $table ="maploginusertoruangan_s";
    protected $fillable = [];
    public $timestamps = false;
}
