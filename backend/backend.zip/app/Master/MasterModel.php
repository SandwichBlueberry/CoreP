<?php

namespace App\Master;

use App\BaseModel;
class MasterModel extends BaseModel
{
    
    
}
