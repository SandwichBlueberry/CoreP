<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 22/05/2018
 * Time: 13.49
 */


namespace App\Master;


class CaraSetor extends MasterModel
{
    protected $table ="carasetor_m";
    protected $fillable = [];
    public $timestamps = false;

}
