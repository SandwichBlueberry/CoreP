<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/23/2019
 * Time: 4:26 PM
 */

namespace App\Master;


class DetailKelompokPegawai extends MasterModel
{
    protected $table ="kelompokpegawai_m";
    protected $fillable = [];
    public $timestamps = false;
}