<?php
/**
 * Created by PhpStorm.
 * User: as@epic
 * Date: 9/19/2017
 * Time: 11:51 PM
 */

namespace App\Master;

class Alamat extends MasterModel
{
    protected $table = 'alamatmt';
    protected $fillable = [];
    public $timestamps = false;

}

