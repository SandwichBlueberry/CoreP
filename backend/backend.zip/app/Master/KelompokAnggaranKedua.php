<?php

namespace App\Master;

class KelompokAnggaranKedua extends MasterModel
{
    protected $table = 'kelompokanggarankedua_m';
    protected $fillable = [];
    public $timestamps = false;


}


