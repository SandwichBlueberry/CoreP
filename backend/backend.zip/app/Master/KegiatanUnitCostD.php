<?php
namespace App\Master;

class KegiatanUnitCostD extends MasterModel
{
    protected $table ="kegiatanunitcostd_m";
    protected $fillable = [];
    public $timestamps = false;
    public $incrementing = false;

//    public function __construct(){$this->setTransformerPath('App\Transformers\Master\KategoryAccountTransformer');}

}
