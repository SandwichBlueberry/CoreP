<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 10/10/2019
 * Time: 9:30 AM
 */
namespace App\Master;

class KelompokAlat extends MasterModel
{
    protected $table = 'kelompokalat_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = 'id';

}
