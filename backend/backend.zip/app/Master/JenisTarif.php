<?php

namespace App\Master;

class JenisTarif extends MasterModel
{
    protected $table ="jenistarif_m";
    protected $fillable = [];

//    public function asal_produk(){
//        return $this->belongsTo('App\Master\AsalProduk', 'objectasalprodukfk');
//    }
}
