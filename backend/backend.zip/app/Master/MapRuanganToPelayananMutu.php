<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 10/10/2019
 * Time: 9:31 AM
 */
namespace App\Master;
class MapRuanganToPelayananMutu extends MasterModel
{
    protected $table = 'mapruangantopelayananmutu_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = 'id';

}
