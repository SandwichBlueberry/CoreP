<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class JenisPegawai extends MasterModel
{
    protected $table ="jenispegawai_m";
    protected $fillable = [];


}
