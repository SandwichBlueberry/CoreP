<?php

namespace App\Master;


class MerkProduk extends MasterModel
{
    protected $table = 'merkproduk_m';
    protected $fillable = [];
    public $timestamps = false;

}


