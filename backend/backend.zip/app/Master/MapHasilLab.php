<?php

namespace App\Master;

class MapHasilLab extends MasterModel
{
    protected $table = 'maphasillab_m';
    protected $fillable = [];
    public $timestamps = false;

}


