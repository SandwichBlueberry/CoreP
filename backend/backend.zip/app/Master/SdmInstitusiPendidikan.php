<?php
/**
 * Created by PhpStorm.
 * User: as@epic
 * Date: 07/12/2018
 * Time: 11.07
 */

namespace App\Master;

class SdmInstitusiPendidikan extends MasterModel
{
    protected $table = 'sdm_institusipendidikan_m';
    protected $fillable = [];
    public $timestamps = false;

}
