<?php

namespace App\Master;

class PelayananMutu extends MasterModel{
    protected $table ="pelayananmutu_m";
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = "id";
}