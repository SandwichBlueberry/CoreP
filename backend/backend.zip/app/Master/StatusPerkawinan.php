<?php
namespace App\Master;
class StatusPerkawinan extends MasterModel{
    protected $table = 'statusperkawinanmt';
    protected $fillable = [];
    public $timestamps = false ;
}
