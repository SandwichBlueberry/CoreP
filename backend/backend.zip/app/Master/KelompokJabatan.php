<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/23/2019
 * Time: 4:16 PM
 */

namespace App\Master;


class KelompokJabatan extends MasterModel
{
    protected $table ="nilaikelompokjabatan_m";
    protected $fillable = [];
    public $timestamps = false;
}