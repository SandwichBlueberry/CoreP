<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;
//use DB;

class MapPegawaiJabatanToUnitKerja extends MasterModel
{
    protected $table = 'mappegawaijabatantounitkerja_m';
    protected $fillable = [];
    public $timestamps = false;

}


