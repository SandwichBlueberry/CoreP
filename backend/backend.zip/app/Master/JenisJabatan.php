<?php
namespace App\Master;

class JenisJabatan extends MasterModel
{
    protected $table ="jenisjabatan_m";
    protected $fillable = [];
    public $timestamps = false;

}
