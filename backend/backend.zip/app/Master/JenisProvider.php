<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class JenisProvider extends MasterModel
{
    protected $table ="jenisprovider_m";
    protected $fillable = [];
    public $timestamps = false;
}
