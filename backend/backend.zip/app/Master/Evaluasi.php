<?php
/**
 * Created by IntelliJ IDEA.
 * User: Egie Ramdan
 * Date: 02/05/2019
 * Time: 10:40
 */


namespace App\Master;

class Evaluasi extends MasterModel
{
	protected $table = 'evaluasi_m';
	protected $fillable = [];
	public $timestamps = false;
	protected $primaryKey = "id";

}
