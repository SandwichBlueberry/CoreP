<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 30/07/2018
 * Time: 14.57
 */
namespace App\Master;

class TipeKoleksi extends MasterModel
{
    protected $table ="sdm_tipekoleksi_m";
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = "id";

}
