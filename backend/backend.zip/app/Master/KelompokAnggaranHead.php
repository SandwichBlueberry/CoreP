<?php

namespace App\Master;

class KelompokAnggaranHead extends MasterModel
{
    protected $table = 'kelompokanggaranhead_m';
    protected $fillable = [];
    public $timestamps = false;


}


