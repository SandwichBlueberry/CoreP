<?php
/**
 * Created by PhpStorm.
 * User: as@epic
 * Date: 07/12/2018
 * Time: 11.07
 */

namespace App\Master;

class SdmFakultas extends MasterModel
{
    protected $table = 'sdm_fakultas_m';
    protected $fillable = [];
    public $timestamps = false;

}
