<?php
/**
 * Created by PhpStorm.
 * User: Khrisnanda
 * Date: 29/01/2020
 * Time: 18:11
 */

namespace App\Master;


class TargetKinerja extends MasterModel
{
    protected $table ="targetkinerja_m";
    protected $fillable = [];
    public $timestamps = false;
}