<?php
/**
 * Created by PhpStorm.
 * User: asepic
 * Date: 11/12/2018
 * Time: 10.52
 */

namespace App\Master;

class DiklatJurusan extends MasterModel
{
    protected $table = 'diklatjurusan_m';
    protected $fillable = [];
    public $timestamps = false;

}
