<?php
/**
 * Created by PhpStorm.
 * User: as@epic
 * Date: 07/12/2018
 * Time: 11.07
 */

namespace App\Master;

class DiklatKategory extends MasterModel
{
    protected $table = 'diklatkategori_m';
    protected $fillable = [];
    public $timestamps = false;

}
