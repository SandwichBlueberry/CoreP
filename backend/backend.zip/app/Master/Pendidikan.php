<?php
namespace App\Master;

class Pendidikan extends MasterModel
{
    protected $table ="pendidikanmt";
    protected $fillable = [];
    public $timestamps = false;
//    public function __construct(){$this->setTransformerPath('App\Transformers\Master\KategoryAccountTransformer');}

}
