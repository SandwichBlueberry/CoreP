<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 22/11/2018
 * Time: 17:13
 */


namespace App\Master;

class DiagnosaKeperawatan extends MasterModel
{
    protected $table = 'diagnosakeperawatan_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = "id";

}
