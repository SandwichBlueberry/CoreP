<?php

namespace App\Master;

class KelompokAnggaranKetujuh extends MasterModel
{
    protected $table = 'kelompokanggaranketujuh_m';
    protected $fillable = [];
    public $timestamps = false;


}


