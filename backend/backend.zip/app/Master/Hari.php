<?php
/**
 * Created by PhpStorm.
 * User: JASAMEDIKA
 * Date: 18/07/2018
 * Time: 16:09
 */

namespace App\Master;


class Hari
{
    protected $table = 'hari_m';
    protected $fillable = [];
    public $timestamps = false;


}