<?php
/**
 * Created by IntelliJ IDEA.
 * User: Egie Ramdan
 * Date: 12/02/2019
 * Time: 13.45
 */
namespace App\Master;

class MapLoginUserToModulAplikasi extends MasterModel
{
	protected $table ="maploginusertomodulaplikasi_s";
	protected $fillable = [];
	public $timestamps = false;
}
