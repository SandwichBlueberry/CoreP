<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/23/2019
 * Time: 4:32 PM
 */

namespace App\Master;


class JamKerja extends MasterModel
{
    protected $table ="jamkerja_m";
    protected $fillable = [];
    public $timestamps = false;
}