<?php
namespace App\Master;

class KegiatanUnitCostH extends MasterModel
{
    protected $table ="kegiatanunitcosth_m";
    protected $fillable = [];
    public $timestamps = false;

//    public function __construct(){$this->setTransformerPath('App\Transformers\Master\KategoryAccountTransformer');}

}
