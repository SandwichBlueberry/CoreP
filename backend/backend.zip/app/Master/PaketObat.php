<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 10/10/2019
 * Time: 9:30 AM
 */
namespace App\Master;

class PaketObat extends MasterModel
{
    protected $table = 'paketobat_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = 'id';

}
