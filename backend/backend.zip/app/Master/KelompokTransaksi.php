<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class KelompokTransaksi extends MasterModel
{
    protected $table ="jenistransaksimt";
    protected $fillable = [];
    public $timestamps = false;



}
