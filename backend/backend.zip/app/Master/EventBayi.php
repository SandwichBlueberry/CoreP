<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class EventBayi extends MasterModel
{
    protected $table ="eventbayi_m";
    protected $fillable = [];

    public $timestamps = false;
    protected $primaryKey = "id";


}
