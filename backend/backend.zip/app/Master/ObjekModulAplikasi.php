<?php

namespace App\Master;

use App\Master\MasterModel;

class ObjekModulAplikasi extends MasterModel
{
    protected $table ="objekmodulaplikasi_s";
    protected $fillable = [];
    public $timestamps = false;
}
