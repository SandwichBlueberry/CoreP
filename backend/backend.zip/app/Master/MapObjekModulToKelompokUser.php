<?php

namespace App\Master;

class MapObjekModulToKelompokUser extends MasterModel
{
    protected $table ="mapobjekmodultokelompokuser_s";
    protected $fillable = [];
    public $timestamps = false;
}
