<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/23/2019
 * Time: 4:32 PM
 */

namespace App\Master;


class ShiftKerja extends MasterModel
{
    protected $table ="shiftkerja_m";
    protected $fillable = [];
    public $timestamps = false;
}