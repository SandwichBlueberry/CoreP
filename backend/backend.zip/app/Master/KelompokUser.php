<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class KelompokUser extends MasterModel
{
    protected $table ="kelompokuser_s";
    protected $fillable = [];
    public $timestamps = false;

}
