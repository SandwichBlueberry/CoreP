<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 18/12/2018
 * Time: 15.49
 */

namespace App\Master;

class IndikatorRensar extends MasterModel
{
    protected $table = 'indikatorrensar_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = 'id';

}
