<?php
/**
 * Created by PhpStorm.
 * User: JASAMEDIKA
 * Date: 18/07/2018
 * Time: 15:10
 */

namespace App\Master;


class JadwalPraktikDokter extends MasterModel
{
    protected $table = 'jadwalpraktikdokter_m';
    protected $fillable = [];
    public $timestamps = false;


}