<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/22/2019
 * Time: 5:03 PM
 */

namespace App\Master;


class StatusPegawai extends MasterModel
{
    protected $table = 'statuspegawai_m';
    protected $fillable = [];
    public $timestamps = false;
}