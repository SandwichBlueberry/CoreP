<?php
namespace App\Master;

class ProfileM extends MasterModel
{
    protected $table ="profile_m";
    protected $fillable = [];
    public $timestamps = false;
     public $incrementing = false;
}
