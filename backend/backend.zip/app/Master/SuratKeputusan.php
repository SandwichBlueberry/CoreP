<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 16/11/2018
 * Time: 11:02
 */

namespace App\Master;

class SuratKeputusan extends MasterModel
{
    protected $table = 'suratkeputusan_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = "id";
}


