<?php

namespace App\Master;

class KelompokAnggaranKelima extends MasterModel
{
    protected $table = 'kelompokanggarankelima_m';
    protected $fillable = [];
    public $timestamps = false;


}


