<?php
/**
 * Created by PhpStorm.
 * User: Ecep
 * Date: 17/10/2018
 * Time: 13:34
 */

namespace App\Master;


class GolonganAsuransi extends MasterModel
{
    protected $table ="golonganasuransi_m";
    protected $fillable = [];
    public $timestamps = false;
}