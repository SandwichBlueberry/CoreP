<?php
/**
 * Created by IntelliJ IDEA.
 * User: Egie Ramdan
 * Date: 22/02/2019
 * Time: 14.31
 */

namespace App\Master;

class WaktuLogin extends MasterModel
{
	protected $table ="waktulogin_m";
	protected $fillable = [];
	public $timestamps = false;
	protected $primaryKey = "id";


}