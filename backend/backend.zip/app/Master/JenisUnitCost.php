<?php
namespace App\Master;

class JenisUnitCost extends MasterModel
{
    protected $table ="jenisunitcost_m";
    protected $fillable = [];

//    public function __construct(){$this->setTransformerPath('App\Transformers\Master\KategoryAccountTransformer');}

}
