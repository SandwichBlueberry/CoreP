<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class MapRuanganToRuanganFisik extends MasterModel
{
    protected $table ="mapruangantoruanganfisik_m";
    protected $fillable = [];


}
