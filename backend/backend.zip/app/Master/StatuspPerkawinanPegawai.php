<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/23/2019
 * Time: 4:39 PM
 */

namespace App\Master;


class StatuspPerkawinanPegawai extends MasterModel
{
    protected $table ="statusperkawinanpegawai_m";
    protected $fillable = [];
    public $timestamps = false;
}