<?php
/**
 * Created by PhpStorm.
 * User: Egie
 * Date: 6/06/2018
 * Time: 11:51 AM
 */

namespace App\Master;

class ProdukDetailLaboratorium extends MasterModel
{
    protected $table = 'produkdetaillaboratorium_m';
    protected $fillable = [];
    public $timestamps = false;

}

