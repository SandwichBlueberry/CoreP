<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 09/04/2018
 * Time: 12.33
 */

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class RunningNumber extends MasterModel
{
    protected $table ="running_number";
    protected $fillable = [];
    public $timestamps = false;

}