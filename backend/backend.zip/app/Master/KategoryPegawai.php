<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/22/2019
 * Time: 5:02 PM
 */

namespace App\Master;


class KategoryPegawai extends MasterModel
{
    protected $table = 'kategorypegawai_m';
    protected $fillable = [];
    public $timestamps = false;
}