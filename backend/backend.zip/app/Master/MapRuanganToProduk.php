<?php

namespace App\Master;

//use Illuminate\Database\Eloquent\Model;

class MapRuanganToProduk extends MasterModel
{
    protected $table = 'mapruangantoproduk_m';
    protected $fillable = [];
    public $timestamps = false;

//    public function __construct(){$this->setTransformerPath('App\Transformers\Master\RuanganTransformer');}

}
