<?php
namespace App\Master;

class KelompokPasien extends MasterModel
{
    protected $table ="kelompokpasienmt";
    protected $fillable = [];

    public function __construct(){$this->setTransformerPath('App\Transformers\Master\KelompokPasienTransformer');}

}
