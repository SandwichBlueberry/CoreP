<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class MapKelompokPasientoPenjamin extends MasterModel
{
    protected $table ="mapkelompokpasientopenjamin_m";
    protected $fillable = [];
    protected $primaryKey = "id";
    public $timestamps = false;

}
