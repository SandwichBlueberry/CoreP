<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;
//use DB;

class TingkatKelulusan extends MasterModel
{
    protected $table = 'tingkatkelulusan_m';
    protected $fillable = [];
    public $timestamps = false;

}


