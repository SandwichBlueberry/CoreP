<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class JenisProduk extends MasterModel
{
    protected $table ="jenisproduk_m";
    protected $fillable = [];

    public $timestamps = false;
    protected $primaryKey = "id";


}
