<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class JenisKelamin extends MasterModel
{
    protected $table ="jeniskelaminmt";
    protected $fillable = [];
}
