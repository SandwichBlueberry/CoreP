<?php
namespace App\Master;

class Bank extends MasterModel
{
    protected $table ="bank_m";
    protected $fillable = [];

//    public function __construct(){$this->setTransformerPath('App\Transformers\Master\KelompokPasienTransformer');}

}
