<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 12/12/2018
 * Time: 09.45
 */


namespace App\Master;

class MapPelatihanPaketToJabatan extends MasterModel
{
    protected $table = "mappelatihanpakettojabatan_m";
    protected $fillable = [];
    public $timestamps = false;
    public $incrementing = false;
    protected $primaryKey = "id";


}
