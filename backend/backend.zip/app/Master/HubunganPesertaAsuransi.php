<?php
/**
 * Created by PhpStorm.
 * User: Ecep
 * Date: 17/10/2018
 * Time: 13:32
 */

namespace App\Master;


class HubunganPesertaAsuransi extends MasterModel
{
    protected $table ="hubunganpesertaasuransi_m";
    protected $fillable = [];
    public $timestamps = false;
}