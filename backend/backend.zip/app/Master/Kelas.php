<?php
namespace App\Master;

class Kelas extends MasterModel
{
    protected $table ="kelasmt";
    protected $fillable = [];

//    public function __construct(){$this->setTransformerPath('App\Transformers\Master\KategoryAccountTransformer');}

}
