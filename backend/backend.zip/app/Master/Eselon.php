<?php
/**
 * Created by PhpStorm.
 * User: Egie Ramdan
 * Date: 17/12/2018
 * Time: 11.29
 */
namespace App\Master;

class Eselon extends MasterModel
{
    protected $table = 'eselon_m';
    protected $fillable = [];
    public $timestamps = false;
    protected $primaryKey = 'id';

}
