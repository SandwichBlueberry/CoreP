<?php
namespace App\Master;

class IndirectUnitCost extends MasterModel
{
    protected $table ="indirectunitcost_m";
    protected $fillable = [];
    public $timestamps = false;
    public $incrementing = false;



}
