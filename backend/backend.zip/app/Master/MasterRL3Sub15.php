<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class MasterRL3Sub15 extends MasterModel
{
    protected $table ="masterrl_3_15_m";
    protected $fillable = [];

    public $timestamps = false;
    protected $primaryKey = "id";


}
