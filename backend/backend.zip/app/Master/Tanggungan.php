<?php
/**
 * Created by IntelliJ IDEA.
 * User: UNKNOWS
 * Date: 4/29/2019
 * Time: 3:46 PM
 */

namespace App\Master;


class Tanggungan extends MasterModel
{
    protected $table ="sdm_tanggungan_m";
    protected $fillable = [];
    public $timestamps = false;
}