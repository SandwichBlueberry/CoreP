<?php
/**
 * Created by PhpStorm.
 * User: asepic
 * Date: 11/12/2018
 * Time: 11.13
 */

//
namespace App\Master;

class JurusanPeminatan extends MasterModel
{
    protected $table = 'jurusanpeminatan_m';
    protected $fillable = [];
    public $timestamps = false;

}
