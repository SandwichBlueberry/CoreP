<?php
namespace App\Master;

class KeluargaPegawai extends MasterModel
{
    protected $table ="keluargapegawai_m";
    protected $fillable = [];
    public $timestamps = false;
}
