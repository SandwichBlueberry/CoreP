<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;
//use DB;

class PasienTriase extends MasterModel
{
    protected $table = 'pasientriasemt';
    protected $fillable = [];
    public $timestamps = false;

}


