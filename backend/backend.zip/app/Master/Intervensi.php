<?php
/**
 * Created by IntelliJ IDEA.
 * User: Uhman
 * Date: 02/05/2019
 * Time: 10:40
 */


namespace App\Master;

class Intervensi extends MasterModel
{
	protected $table = 'intervensi_m';
	protected $fillable = [];
	public $timestamps = false;
	protected $primaryKey = "id";

}
