<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class Bku extends MasterModel
{
    protected $table ="bku_m";
    protected $fillable = [];
    public $timestamps = false;



}