<?php

namespace App\Master;


class SettingDataFixed extends MasterModel{

  protected $table = 'settingdatafixedmt';
  protected $fillable = [];
  public $timestamps = false;

}


