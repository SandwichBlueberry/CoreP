<?php

namespace App\Master;

// use Illuminate\Database\Eloquent\Model;

class JenisPersalinan extends MasterModel
{
    protected $table ="rm_jenispersalinan_m";
    protected $fillable = [];

    public $timestamps = false;
    protected $primaryKey = "id";


}
