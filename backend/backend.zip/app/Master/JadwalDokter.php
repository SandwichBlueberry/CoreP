<?php
/**
 * Created by PhpStorm.
 * User: JASAMEDIKA
 * Date: 18/07/2018
 * Time: 15:10
 */

namespace App\Master;


class JadwalDokter extends MasterModel
{
    protected $table = 'jadwaldokter_m';
    protected $fillable = [];
    public $timestamps = false;


}