<?php

namespace App\Master;

class MataUang extends MasterModel
{
    protected $table ="matauang_m";
    protected $fillable = [];


}
