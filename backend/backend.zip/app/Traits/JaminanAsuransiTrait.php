<?php
namespace App\Traits;

//use App\Master\ChartOfAccount;
//use App\Transaksi\PeriodeAccount;
//use App\Transaksi\PeriodeAccountSaldo;
Trait JaminanAsuransiTrait
{
        protected function abc(){}
}